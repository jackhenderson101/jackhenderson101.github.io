import pickle

import zmq


class ZMQChannel:

    def __init__(self, port, bind=False):
        self.context = zmq.Context()
        self.zmq_sync = self.context.socket(zmq.PAIR)
        if bind:
            self.zmq_sync.bind("tcp://*:%d" % port)
        else:
            self.zmq_sync.connect("tcp://localhost:%d" % port)

    def send_signal(self):
        self.zmq_sync.send(b"")

    def send(self, data):
        raw_data = pickle.dumps(data, protocol=4)
        self.zmq_sync.send(raw_data)

    def receive(self):
        raw_data = self.zmq_sync.recv()
        if len(raw_data) > 0:
            return pickle.loads(raw_data)
        else:
            return None
