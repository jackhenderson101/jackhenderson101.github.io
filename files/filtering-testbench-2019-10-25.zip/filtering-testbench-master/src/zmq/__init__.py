"""
List of messages currently in use:


signals/init
signals/ready/{process name}
signals/stop



"""