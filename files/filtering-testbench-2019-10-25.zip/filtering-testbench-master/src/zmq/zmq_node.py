import zmq
import pickle
import msgpack
import msgpack_numpy

msgpack_numpy.patch()


# noinspection PyUnresolvedReferences
class ZMQNode:

    def __init__(self, incoming_port=9991, outgoing_port=9990):

        self.context = zmq.Context()

        self.incoming = self.context.socket(zmq.SUB)
        self.incoming.connect("tcp://localhost:%d" % incoming_port)

        self.outgoing = self.context.socket(zmq.PUB)
        self.outgoing.connect("tcp://localhost:%d" % outgoing_port)

        # Set the high-water mark to infinite so we don't drop any packets. Need to be careful about memory usage though
        self.incoming.setsockopt(zmq.RCVHWM, 0)
        self.outgoing.setsockopt(zmq.SNDHWM, 0)

        self.subscribe("signals/stop")
        self.subscribe("signals/init")
        self.subscribe("meta")

        self.msg_len = 0
        self.total_msgs_rx = 0
        self.total_msgs_tx = 0
        self.max_len = 0

    def subscribe(self, topic):
        self.incoming.setsockopt(zmq.SUBSCRIBE, topic.encode())

    def send_signal(self, topic):
        self.total_msgs_tx += 1
        self.outgoing.send_multipart([topic.encode(), b""])

    def send(self, topic, data):
        self.total_msgs_tx += 1
        self.outgoing.send_multipart([topic.encode(), pickle.dumps(data)])

    def send_msgpack(self, topic, data):
        self.outgoing.send_multipart([topic.encode(), msgpack.dumps(data)])

    def receive(self, nowait=False):
        """
        Receive a message from the publisher. Blocks until a message is available, unless nowait is True.
        If nowait is True, and a message is not immediately available, (None, None) is returned.
        """
        if nowait:
            try:
                message = self.incoming.recv_multipart(zmq.DONTWAIT)
            except zmq.error.Again:
                return None, None
        else:
            message = self.incoming.recv_multipart()

        topic = message[0].decode()

        if len(message[1]) > 0:
            data = pickle.loads(message[1])
        else:
            data = None

        self.msg_len += len(message[1])
        self.total_msgs_rx += 1
        self.max_len = max(self.max_len, len(message[1]))

        return topic, data

    def print_stats(self):
        print("Received messages: %d, avg_len: %.1f, max_len: %d"
              % (self.total_msgs_rx, self.msg_len / self.total_msgs_rx, self.max_len))
        print("Sent messages: %d" % self.total_msgs_tx)

