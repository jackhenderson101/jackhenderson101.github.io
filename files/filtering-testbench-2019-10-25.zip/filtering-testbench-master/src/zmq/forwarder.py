import zmq


# noinspection PyUnresolvedReferences
class Forwarder:
    """
    The forwarder acts as the intermediary between all the services. All published messages get received by the frontend
    socket and then re-published by the backend socket.
    """

    def __init__(self, incoming_port=9990, outgoing_port=9991):

        self.context = zmq.Context(1)

        # Socket facing clients
        self.frontend = self.context.socket(zmq.SUB)
        self.frontend.bind("tcp://*:%d" % incoming_port)
        self.frontend.setsockopt(zmq.SUBSCRIBE, b"")
        self.frontend.setsockopt(zmq.RCVHWM, 0)

        # Socket facing services
        self.backend = self.context.socket(zmq.PUB)
        self.backend.bind("tcp://*:%d" % outgoing_port)
        self.backend.setsockopt(zmq.SNDHWM, 0)

        self.run()

    def run(self):
        try:
            zmq.device(zmq.FORWARDER, self.frontend, self.backend)
        except Exception as e:
            print(e)
            print("bringing down zmq device")
        finally:
            self.frontend.close()
            self.backend.close()
            self.context.term()
