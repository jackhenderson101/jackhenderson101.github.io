import numpy as np
from typing import List

from src.structs.landmark import Landmark
from src.geometry.pose import Pose
from src.geometry.point_referenced import Point3DReferenced
from src.geometry.twist import Twist


class Message:
    """
    Represents an object than can be send over the communications channel
    """
    def __init__(self, time_step: int):
        self.time_step = time_step


class SimulationMeta:
    def __init__(self, simulation_name: str, datetime: str, num_steps: int, time_delta: float, landmarks: List[Landmark]):
        self.simulation_name = simulation_name
        self.datetime = datetime
        self.num_steps = num_steps
        self.time_delta = time_delta
        self.landmarks = landmarks


class DiagnosticData(Message):
    def __init__(self, time_step, data: np.ndarray):
        super().__init__(time_step)
        self.data = data


class VelocityMeasurement(Message):
    """
    Represents a single velocity measurement for a single robot.
    """

    def __init__(self, vel: Twist, covariance: np.ndarray, time_step):
        assert isinstance(covariance, np.ndarray) and covariance.shape == (6, 6)

        super().__init__(time_step)
        self.vel = vel
        self.covariance = covariance


class LandmarkMeasurement(Message):
    """
    Represents a measurement of a fixed, known landmark by a robot, represented in the robot's coordinate frame
    """

    def __init__(self, meas_pos: Point3DReferenced, covariance: np.ndarray, landmark: Landmark, time_step):
        assert isinstance(covariance, np.ndarray) and covariance.shape == (3, 3)

        super().__init__(time_step)

        self.meas_pos = meas_pos
        self.covariance = covariance
        self.landmark = landmark


class RobotMeasurement(Message):
    """
    Represents a relative measurement between two robots i and j.
    The measurement is between a known point in j's body fixed frame and the origin of i's BFF. The measurement is given
    in i's coordinate frame.
    """

    def __init__(self, meas_pos: Point3DReferenced, covariance: np.ndarray, robot_name: str, time_step: int):
        assert isinstance(covariance, np.ndarray) and covariance.shape == (3, 3)
        super().__init__(time_step)

        self.meas_pos = meas_pos
        self.covariance = covariance
        self.robot_name = robot_name  # The robot that was measured (j)


class R2RMessage(Message):
    """
    Represents a transmitted message from robot j to robot i. The message contains information about j's state estimate.
    """
    def __init__(self, tx_name: str, body_ref_point: Point3DReferenced, world_ref_point: Point3DReferenced,
                 state_covariance: np.ndarray, time_step: int, state_estimate: np.ndarray = None, covariance_column: np.ndarray = None):
        super().__init__(time_step)

        self.tx_name = tx_name  # The robot sending the message (j)
        self.body_ref_point = body_ref_point  # m_j
        self.world_ref_point = world_ref_point  #
        self.state_covariance = state_covariance
        self.comms_covariance = 0
        self.state_estimate = state_estimate
        self.covariance_column = covariance_column


class CrossCovariancePart(Message):

    def __init__(self, time_step: int, K: np.ndarray):
        super().__init__(time_step)
        self.K = K

class ThirdPartyLandmarkUpdate(Message):

    def __init__(self, time_step: int, Sigma_delta: np.ndarray, L_i: np.ndarray):
        super().__init__(time_step)
        self.Sigma_delta = Sigma_delta
        self.L_i = L_i

class ThirdPartyRobotUpdate(Message):
    def __init__(self, time_step: int, Sigma_delta: np.ndarray, L_i: np.ndarray):
        super().__init__(time_step)
        self.Sigma_delta = Sigma_delta
        self.L_i = L_i

class Estimate(Message):

    def __init__(self, state_estimate: Pose, covariance, time_step):
        super().__init__(time_step)
        self.state_estimate = state_estimate
        self.covariance = covariance
