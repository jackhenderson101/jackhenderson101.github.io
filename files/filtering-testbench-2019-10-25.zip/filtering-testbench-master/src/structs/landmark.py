from src.geometry.point_referenced import Point3DReferenced


class Landmark:
    """
    A landmark is a fixed point in the inertial frame that can be uniquely identified by a robot
    """

    def __init__(self, name: str, location: Point3DReferenced):
        self.name = name
        self.location = location
