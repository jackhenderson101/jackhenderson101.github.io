from typing import List
import numpy as np
from src.geometry.SE3 import SE3


class EstimationError:
    def __init__(self, time_step: int, transformation: SE3):
        self.time_step = time_step
        self.error = transformation
        self.rotation_error = transformation.rotation.angle_from_zero()
        self.translation_error = transformation.translation.l2_norm()


class AverageEstimationError:
    def __init__(self, time_step: int, errors: List[EstimationError]):
        self.time_step = time_step

        self.rotation_error = np.mean(list(map(lambda e: e.rotation_error, errors)))
        self.translation_error = np.mean(list(map(lambda e: e.translation_error, errors)))

