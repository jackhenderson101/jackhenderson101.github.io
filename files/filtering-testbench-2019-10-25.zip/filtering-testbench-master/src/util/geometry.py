import numpy as np
import numba
I3 = np.eye(3)


def is_skew_symmetric(M):
    """ Determine if a matrix is skew symmetric. i.e M.T == -M """
    return isinstance(M, np.ndarray) and M.shape == (3, 3) and np.allclose(M.T + M, 0)


def is_symmetric(M):
    return isinstance(M, np.ndarray) and np.allclose(M, M.T)


def is_se3(M):
    """ Return true is a matrix has the properties of an s"""
    return isinstance(M, np.ndarray) and M.shape == (4, 4) and np.all(M[3, :] == 0) and is_skew_symmetric(M[0:3, 0:3])


@numba.njit(cache=True)
def skew(w: np.ndarray) -> np.ndarray:
    """
    Create a skew-symmetric matrix, w_x, from a vector, w, using the following form
           |    0  -w_3    w_2 |
    w_x =  |  w_3     0   -w_1 |
           | -w_2   w_1      0 |

    @:param w: A 3x1 numpy array
    """
    # assert isinstance(w, np.ndarray) and (w.shape == (3,) or w.shape == (3, 1))
    return np.array([[0, -w[2], w[1]], [w[2], 0, -w[0]], [-w[1], w[0], 0]])


def vex(w_x: np.ndarray) -> np.ndarray:
    """
    Perform the inverse operation of skew to recover a vector, w, from w_x
    :param w_x: a 3x3 skew-symmetric numpy matrix
    """
    assert is_skew_symmetric(w_x), "Vex can only be applied to skew-symmetric matrices"

    return np.array([w_x[2, 1], w_x[0, 2], w_x[1, 0]])


def se3_vex(M: np.ndarray) -> np.ndarray:
    """
    Convert from se3 to R^6
    """
    assert is_se3(M), "Cannot apply vex to non-se3 element: " + str(M)

    return np.concatenate((vex(M[0:3, 0:3]), M[0:3, 3]))


def se3_projection(M: np.ndarray):
    """
    Orthogonal projection of a 4x4 matrix onto se3.

    P([M1 M2])  = [ P_a(M1)  M2 ]
     ([M3 M4])    [   0      M4 ]

    Defined in Zamani and Trumpf, 2019
    """
    assert isinstance(M, np.ndarray) and M.shape == (4, 4), "se3 projection must be applied to 4x4 matrix"

    out = np.zeros((4, 4))
    out[0:3, 0:3] = skew_symmetric_projection(M[0:3, 0:3])
    out[0:3, 3] = M[0:3, 3]

    return out


def skew_symmetric_projection(M: np.ndarray):
    """
    Symmetric projection of M, an nxn matrix
    Defined in Zamani and Trumpf, 2019
    """
    assert isinstance(M, np.ndarray) and M.shape[0] == M.shape[1], "Cannot apply skew-symmetric projection to non-square matrix"
    return 0.5 * (M - M.T)


# @numba.njit(cache=True)
def symmetric_projection(M: np.ndarray):
    """
    Symmetric projection of M, an nxn matrix
    Defined in Zamani and Trumpf, 2019
    """
    assert isinstance(M, np.ndarray) and M.shape[0] == M.shape[1], "Cannot apply symmetric projection to non-square matrix"
    return 0.5 * (M + M.T)


@numba.njit(cache=True)
def trace_projection(S: np.ndarray):
    """
    TODO: What is this actually called??
    Trace projection? of a symmetric matrix, defined as trace(S)*I - S

    Defined in Zamani and Trumpf, 2019 - Eqn (16)
    """
    # assert isinstance(S, np.ndarray) and np.all(S == S.T), "Cannot apply trace projection to non-symmetric matrix"
    return np.trace(S) * np.eye(S.shape[0]) - S


def is_positive_definite(matrix: np.ndarray) -> bool:
    """
    Return true if a matrix is positive definite.
    Algorithm from https://stackoverflow.com/questions/16266720/find-out-if-matrix-is-positive-definite-with-numpy
    (A matrix is positive definite iff is has a cholesky factoristation)
    """
    try:
        np.linalg.cholesky(matrix)
        return True
    except np.linalg.linalg.LinAlgError as err:
        if 'Matrix is not positive definite' in err.args:
            return False
        else:
            raise err


def is_roughly_positive_definite(matrix: np.ndarray) -> bool:
    if is_positive_definite(matrix):
        return True
    if not is_symmetric(matrix):
        return False
    eig_vals = np.linalg.eigvals(matrix)
    return abs(max(eig_vals) / min(eig_vals)) > 1000


@numba.njit(cache=True)
def exponential_map(w):
    """
    Compute the exponential map of w using Rodrigues' Formula. Equivalent to scipy.linalg.expm(skew(w)) and much faster

    See https://en.wikipedia.org/wiki/Axis%E2%80%93angle_representation#Relationship_to_other_representations
    :param w: angular velocity (numpy 3 vector)
    """
    theta = np.linalg.norm(w)
    # TODO need to handle small theta better. PHD-57
    if theta == 0:
        return I3
    K = skew(w / theta)
    R = I3 + np.sin(theta) * K + (1-np.cos(theta)) * (K @ K)
    return R
