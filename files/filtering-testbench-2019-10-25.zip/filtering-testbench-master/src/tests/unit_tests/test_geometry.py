import random
import unittest
import numpy as np
import scipy

from src.geometry.pose import Pose, WorldFrame
from src.geometry.coordinate_transform import CoordinateTransform
from src.geometry.SE3 import SE3
from src.geometry.point import Point3D
from src.geometry.point_referenced import Point3DReferenced
from src.geometry.vector3 import Vector3
from src.geometry.rotations import RotationMatrix, Quaternion, default_rotation
from src.util.geometry import exponential_map, skew


class TestGeometry(unittest.TestCase):

    def random_rotation(self):
        t1 = random.random() * 2 * np.pi
        t2 = random.random() * 2 * np.pi
        t3 = random.random() * 2 * np.pi
        R_m: RotationMatrix = RotationMatrix.rotx(t1) * RotationMatrix.roty(t2) * RotationMatrix.rotz(t3)
        R_q: Quaternion = Quaternion.rotx(t1) * Quaternion.roty(t2) * Quaternion.rotz(t3)
        return R_m, R_q

    def test_Point3D(self):
        # Test list constructor
        p1 = Point3D([1, 2, 3])
        assert np.all(p1.xyz == np.array([1, 2, 3]))

        # Test tuple constructor
        p2 = Point3D((4, 5, 6))
        assert np.all(p2.xyz == np.array([4, 5, 6]))

        # Test add operator
        assert np.all((p1 + p2).xyz == np.array([5, 7, 9]))

        # Test rotate by a quaternion
        default_rotation.rotx(np.pi) * p1

    def test_rotations(self):
        for i in range(50):
            (R_m, R_q) = self.random_rotation()

            self.assertEqual(R_m, R_q)
            self.assertEqual(R_q, R_m)

            # Test conversion between quaternion and rotation matrices
            self.assertEqual(Quaternion.from_rotation_matrix(R_q.as_matrix()), R_q)
            self.assertEqual(RotationMatrix.from_quaternion(R_m.as_quaternion()), R_m)

            self.assertEqual(R_q.inverse().inverse(), R_q)
            self.assertEqual(R_m.inverse().inverse(), R_m)
            self.assertEqual(R_m.inverse(), R_q.inverse())

    def test_CoordinateTransformation(self):
        r = Quaternion

        A = Pose(SE3(r.rotz(-0.5 * np.pi), Point3D([0, 10, 0])), "A", WorldFrame)
        B = Pose(SE3(r.rotz(0.5 * np.pi), Point3D([10, 0, 0])), "B", WorldFrame)
        C = Pose(SE3(r.rotz(0.5 * np.pi), Point3D([10, 0, 0])), "C", B)

        p1 = Point3DReferenced([5, 0, 0], WorldFrame)

        T_W_A = CoordinateTransform.calculate_transform(WorldFrame, A)

        # print(T_W_A)

        # print(p1)
        p1_A = T_W_A * p1

        self.assertEqual(p1_A.reference.name, "A")
        self.assertTrue(np.all(p1_A.xyz == np.array([10, 5, 0])))

        T_A_B = CoordinateTransform.calculate_transform(A, B)
        # print(T_A_B)

        # Should raise because p1 is defined in World frame
        self.assertRaises(Exception, lambda: T_A_B * p1)

        # print(T_A_B * T_W_A * p1)

        # Test nested frames
        T_W_C = CoordinateTransform.calculate_transform(WorldFrame, C)
        T_C_W = CoordinateTransform.calculate_transform(C, WorldFrame)
        # print(T_W_C)
        # print(T_C_W)
        # print(T_C_W.inverse())
        self.assertEqual(T_C_W.inverse(), T_W_C)

        T_A_C = CoordinateTransform.calculate_transform(A, C)
        # print(T_A_C)

    def test_integration(self):

        vel = Vector3(np.array([np.pi/10, 0, 0]))
        R_q_1 = Quaternion.identity().integrate_velocity(vel, 1)
        R_m_1 = RotationMatrix.identity().integrate_velocity(vel, 1)

        self.assertEqual(R_q_1, Quaternion.rotx(np.pi/10))
        self.assertEqual(R_m_1, RotationMatrix.rotx(np.pi/10))

        # Should rotate by 2*pi
        R_q_2 = Quaternion.identity().integrate_velocity(vel, 20)
        self.assertEqual(Quaternion.identity(), R_q_2)

        # Rotate by 4*pi
        R_q_2 = Quaternion.identity().integrate_velocity(vel, 40)
        self.assertEqual(Quaternion.identity(), R_q_2)

        for i in range(50):

            R_m, R_q = self.random_rotation()
            vel = Vector3(np.random.rand(3))
            R_q_1 = R_q.integrate_velocity(vel, 1)
            R_m_1 = R_m.integrate_velocity(vel, 1)

            # Check consistency between rotation matrix form and quaternion form
            self.assertEqual(R_m_1, R_q_1)

    def test_exponential_map(self):
        for i in range(50):

            w = np.random.rand(3)
            exp_w = exponential_map(w)
            exp_w_2 = scipy.linalg.expm(skew(w))
            self.assertTrue(np.allclose(exp_w, exp_w_2))



