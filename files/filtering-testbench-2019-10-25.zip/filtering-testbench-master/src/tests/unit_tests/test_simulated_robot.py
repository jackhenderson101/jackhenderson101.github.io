import unittest

import numpy as np

from src.structs.landmark import Landmark
from data.simulated.robot import Robot
from data.simulated.trajectory import stationary_trajectory
from src.geometry.pose import Pose, WorldFrame
from src.geometry.SE3 import SE3
from src.geometry.point import Point3D
from src.geometry.point_referenced import Point3DReferenced
from src.geometry.rotations import RotationMatrix

Z3 = np.zeros((3, 3))
R1_pose = Pose(SE3(RotationMatrix.rotz(np.pi / 2), Point3D([1, 2, 0])), 'R1', WorldFrame)
R1 = Robot('R1', R1_pose, stationary_trajectory(R1_pose, 1), 1, 0.1)

R2_pose = Pose(SE3(RotationMatrix.rotz(0), Point3D([10, 15, 0])), 'R2', WorldFrame)
R2 = Robot('R2', R2_pose, stationary_trajectory(R2_pose, 1),  1, 0.1)

L1 = Landmark('L1', Point3DReferenced([5, 5, 0], WorldFrame))


class TestSimulatedRobot(unittest.TestCase):

    def test_landmark_measurements(self):
        meas = R1.get_landmark_measurement(L1, 0)
        self.assertTrue(np.allclose(meas.meas_pos.xyz, [3, -4, 0]))
        self.assertEqual(meas.meas_pos.reference, R1.trajectory[0][0])

        meas = R2.get_landmark_measurement(L1, 0)
        self.assertTrue(np.allclose(meas.meas_pos.xyz, [-5, -10, 0]))
        self.assertEqual(meas.meas_pos.reference, R2.trajectory[0][0])

    def test_relative_robot_measurements(self):
        meas = R1.get_robot_measurement(R2, 0)
        self.assertTrue(np.allclose(meas.meas_pos.xyz, [13, -10, 0]))
        self.assertEqual(meas.meas_pos.reference, R1.trajectory[0][0])

        meas = R2.get_robot_measurement(R1, 0)
        self.assertTrue(np.allclose(meas.meas_pos.xyz, [-9, -12, 0]))
        self.assertEqual(meas.meas_pos.reference, R2.trajectory[0][0])
