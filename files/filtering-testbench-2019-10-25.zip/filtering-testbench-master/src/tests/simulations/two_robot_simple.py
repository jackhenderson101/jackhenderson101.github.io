from multiprocessing import Process
from typing import List

import numpy as np
import scipy
from scipy.linalg import expm

from src.filters.central_game_inverse import Central_GAME_SE3_Inverse
from src.structs.landmark import Landmark
from data.simulated.robot import Robot
from data.simulated.trajectory import circular_trajectory
from data.simulated.world import World
from src.filters import FilterMeta
from src.filters.central_game import Central_GAME_SE3
from src.filters.game import GAME_SE3
from src.geometry.point import Point3D
from src.geometry.pose import Pose, WorldFrame
from src.geometry.point_referenced import Point3DReferenced
from src.geometry.twist import Twist
from src.geometry.SE3 import SE3
from src.geometry.vector3 import Vector3
from src.geometry.rotations import default_rotation
from src.tests.simulations import Simulation
from src.util.geometry import skew


class TwoRobotSimple(Simulation):

    def _create_world(self) -> World:

        print("Creating dataset...")

        total_time = 30
        time_delta = .01
        world = World(10, total_time, time_delta)

        # Set initial values for the state
        # Initial rotation matrix
        theta_0 = np.deg2rad(0)
        q_0 = default_rotation.from_rotation_matrix(expm(theta_0 * skew(np.array([0, 0, 1]))))

        # Initial position
        p_0 = [
            (0, 1, 1),
            (0,  -1, 0)
        ]

        # the true angular velocity input
        ang_vel = Vector3(.5 * 3 * np.array([0.01, -0.3, np.sin(.5 * np.pi / 43)]))
        # the true linear velocity input
        lin_vel = Vector3(.5 * np.array([1, 0, 0.1]))
        vel = Twist(ang_vel, lin_vel)

        # Standard deviations for measurement noise
        ang_vel_noise = 0.01 * np.eye(3)
        lin_vel_noise = 0.05 * np.eye(3)
        landmark_measurement_noise = 0.1 * np.eye(3)
        relative_measurement_noise = 0.1 * np.eye(3)
        communication_noise = 0 * np.eye(3)

        for i in range(2):
            name = "R%d" % i
            # True initial position
            p_0_i = Point3D(p_0[i])
            x_0 = Pose(SE3(q_0, p_0_i), "x_0", WorldFrame)

            trajectory = circular_trajectory(x_0, vel, world.num_steps, world.time_delta, name)
            robot = Robot(name, x_0, trajectory, world.rand_int(), world.time_delta)
            robot.set_measurement_errors(ang_vel_noise, lin_vel_noise, landmark_measurement_noise,
                                         relative_measurement_noise)
            world.add_robot(robot)

        landmark_positions = [
            (0, 0, 0),
            (5, -8, 3),
        ]

        for i in range(2):
            landmark = Landmark("L%d" % i, Point3DReferenced(landmark_positions[i], WorldFrame))
            world.add_landmark(landmark)

        world.set_can_see_landmark(TwoRobotSimple.can_see_landmark)

        world.set_can_see_robot(TwoRobotSimple.can_see_robot)
        world.set_communication_noise(communication_noise)

        return world

    @classmethod
    def can_see_landmark(cls, robot, landmark, time_step):
        # Each robot can only see one landmark. eg. R0 can see L0, R1 can see L1 etc.
        return time_step % 10 == 0 and robot.name[1:] == landmark.name[1:]

    @classmethod
    def can_see_robot(cls, robot_tx: Robot, robot_rx: Robot, time_step):
        # Robots can communicate to those adjacent to each other
        connectivity = [
            [0, 1],
            [1, 0],
        ]

        tx_id = int(robot_tx.name[1:])
        rx_id = int(robot_rx.name[1:])
        return time_step % 10 == 1 and connectivity[tx_id][rx_id] == 1

    def _create_filters(self) -> List[FilterMeta]:
        # Initial estimated position
        p_est_0 = [
            (0, 1, 0),
            (0, -1, 0),
        ]

        theta_0 = 0

        filters = []
        targets = []
        estimates = []
        covariances = []

        for i in range(2):
            target = "R%d" % i
            targets.append(target)

            # Estimated initial position
            p_est_0_i = Point3D(p_est_0[i])
            theta_est_0 = theta_0 + np.deg2rad(0)
            q_est_0 = default_rotation.from_rotation_matrix(expm(theta_est_0 * skew(np.array([0, 0, 1]))))
            x_est_0 = Pose(SE3(q_est_0, p_est_0_i), "x_est_0", WorldFrame)
            estimates.append(x_est_0)
            invcov_est_0 = np.block(
                [[100 * np.diag([1, 1, 1]), np.zeros((3, 3))], [np.zeros((3, 3)), 100 * np.diag([1, 1, 1])]])

            covariances.append(invcov_est_0)
            identifier = "GAME - Covariance"
            process = Process(target=GAME_SE3, args=(identifier, 8000 + 10 * i, [target], x_est_0, invcov_est_0), kwargs={
                'covariance_estimation_method': 'covariance',
            })
            filters.append(FilterMeta([target], identifier, process, 8000 + 10 * i))

        # Create central game filter
        identifier = "Central Game"
        block_cov = scipy.linalg.block_diag(*covariances)
        process = Process(target=Central_GAME_SE3, args=(identifier, 9001, targets, estimates, block_cov))
        filters.append(FilterMeta(targets, identifier, process, 9001))

        identifier = "Central Game Inverse"
        process = Process(target=Central_GAME_SE3_Inverse, args=(identifier, 9002, targets, estimates, block_cov))
        filters.append(FilterMeta(targets, identifier, process, 9002))
        return filters


if __name__ == '__main__':
    test = TwoRobotSimple()
    test.run()
    test.post_process()
