from multiprocessing import Process
from typing import List

import numpy as np
import scipy
from scipy.linalg import expm

from src.filters.central_game_inverse import Central_GAME_SE3_Inverse
from src.filters.decoupled_central_game import Central_GAME_SE3_Decoupled
from src.structs.landmark import Landmark
from data.simulated.robot import Robot
from data.simulated.trajectory import circular_trajectory, random_trajectory
from data.simulated.world import World
from src.filters import FilterMeta
from src.filters.central_game import Central_GAME_SE3
from src.filters.game import GAME_SE3
from src.geometry.point import Point3D
from src.geometry.pose import Pose, WorldFrame
from src.geometry.point_referenced import Point3DReferenced
from src.geometry.twist import Twist
from src.geometry.SE3 import SE3
from src.geometry.vector3 import Vector3
from src.geometry.rotations import default_rotation
from src.tests.simulations import Simulation
from src.util.geometry import skew


class Decoupled_GAME_Test(Simulation):

    num_robots = 4

    def _create_world(self) -> World:

        print("Creating dataset...")

        total_time = 20
        time_delta = .01
        world = World(10, total_time, time_delta)

        # Set initial values for the state
        # Initial rotation matrix

        q_0 = [
            default_rotation.rotx(0.4),
            default_rotation.roty(0),
            default_rotation.rotz(0.4),
            default_rotation.rotx(-0.4)
        ]

        # Initial position
        p_0 = [
            (0, 1, 1),
            (0, -1, 0),
            (1, 2, 0),
            (-1, 0, 1)
        ]

        # the true angular velocity input
        ang_vel = Vector3(0.1* 3 * np.array([0.01, -0.3, np.sin(.5 * np.pi / 43)]))
        # the true linear velocity input
        lin_vel = Vector3( np.array([1, 0, 0.1]))
        vel = Twist(ang_vel, lin_vel)

        # Standard deviations for measurement noise
        ang_vel_noise = 0.05 * np.eye(3)
        lin_vel_noise = 0.05 * np.eye(3)
        landmark_measurement_noise = 0.5 * np.eye(3)
        relative_measurement_noise = 0.5 * np.eye(3)
        communication_noise = 0 * np.eye(3)

        for i in range(self.num_robots):
            name = "R%d" % i
            # True initial position
            p_0_i = Point3D(p_0[i])
            x_0 = Pose(SE3(q_0[i], p_0_i), "x_0", WorldFrame)

            trajectory = circular_trajectory(x_0, vel, world.num_steps, world.time_delta, name)
            robot = Robot(name, x_0, trajectory, world.rand_int(), world.time_delta)
            robot.set_measurement_errors(ang_vel_noise, lin_vel_noise, landmark_measurement_noise,
                                         relative_measurement_noise)
            world.add_robot(robot)

        landmark_positions = [
            (0, 0, 0),
            (-2, -3, 3),
            (1, -2, -1)
        ]

        for i in range(len(landmark_positions)):
            landmark = Landmark("L%d" % i, Point3DReferenced(landmark_positions[i], WorldFrame))
            world.add_landmark(landmark)

        world.set_can_see_landmark(Decoupled_GAME_Test.can_see_landmark)

        world.set_can_see_robot(Decoupled_GAME_Test.can_see_robot)
        world.set_communication_noise(communication_noise)

        return world

    @classmethod
    def can_see_landmark(cls, robot, landmark, time_step):
        # Each robot can only see one landmark. eg. R0 can see L0, R1 can see L1 etc.
        return time_step % 10 == 0 and robot.name == "R0" #  robot.name[1:] == landmark.name[1:]

    @classmethod
    def can_see_robot(cls, robot_tx: Robot, robot_rx: Robot, time_step):
        # return False
        # Robots can communicate to those adjacent to each other
        connectivity = [
            [0, 1, 1, 1],
            [1, 0, 1, 1],
            [1, 1, 0, 1],
            [1, 1, 1, 0]
        ]

        tx_id = int(robot_tx.name[1:])
        rx_id = int(robot_rx.name[1:])
        # Connected in a loop 0-1-2-3-0
        # return time_step % 10 == 0 and (rx_id == (tx_id + 1) % 4 or rx_id == (tx_id - 1) % 4)
        return time_step > 0 and time_step % 20 == 5 and connectivity[tx_id][rx_id] == 1

    def _create_filters(self) -> List[FilterMeta]:
        # Initial estimated position
        p_est_0 = [
            (0, 1, 1.5),
            (0, -1, 0.5),
            (1.5, 2, 0),
            (-1.5, 0, 1)
        ]

        q_est_0 = [
            default_rotation.rotx(0.4+0.2),
            default_rotation.roty(0.4+0.1),
            default_rotation.rotz(0.4+0.1),
            default_rotation.rotx(-0.4+0.1)
        ]

        theta_0 = 0

        filters = []
        targets = []
        estimates = []
        covariances = []

        for i in range(self.num_robots):
            target = "R%d" % i
            targets.append(target)

            # Estimated initial position
            p_est_0_i = Point3D(p_est_0[i])
            x_est_0 = Pose(SE3(q_est_0[i], p_est_0_i), "x_est_0", WorldFrame)
            estimates.append(x_est_0)
            invcov_est_0 = np.block(
                [[100 * np.diag([1, 1, 1]), np.zeros((3, 3))], [np.zeros((3, 3)), 100 * np.diag([1, 1, 1])]])

            covariances.append(invcov_est_0)

        # Create central game filter
        block_cov = scipy.linalg.block_diag(*covariances)

        identifier = "Central GAME"
        process = Process(target=Central_GAME_SE3_Inverse, args=(identifier, 9002, targets, estimates, block_cov))
        filters.append(FilterMeta(targets, identifier, process, 9002))

        for i in range(self.num_robots):
            identifier = "Decoupled GAME"
            process = Process(target=Central_GAME_SE3_Decoupled, args=(identifier, 8000 + i, [targets[i]], [estimates[i]], block_cov, targets))
            filters.append(FilterMeta([targets[i]], identifier, process, 8000+i))

            identifier = "Non-collaborative GAME"
            process = Process(target=GAME_SE3, args=(identifier, 7000 + i, [targets[i]], estimates[i], covariances[i]))
            filters.append(FilterMeta([targets[i]], identifier, process, 7000+i))

        return filters


if __name__ == '__main__':
    test = Decoupled_GAME_Test()
    # test.run()
    test.post_process()
