from multiprocessing import Process
from typing import List

import numpy as np
import scipy
from scipy.linalg import expm

from src.filters.central_game_inverse import Central_GAME_SE3_Inverse
from src.structs.landmark import Landmark
from data.simulated.robot import Robot
from data.simulated.trajectory import circular_trajectory
from data.simulated.world import World
from src.filters import FilterMeta
from src.filters.central_game import Central_GAME_SE3
from src.filters.game import GAME_SE3
from src.geometry.point import Point3D
from src.geometry.pose import Pose, WorldFrame
from src.geometry.point_referenced import Point3DReferenced
from src.geometry.twist import Twist
from src.geometry.SE3 import SE3
from src.geometry.vector3 import Vector3
from src.geometry.rotations import default_rotation
from src.tests.simulations import Simulation


class BehzadASCCTest(Simulation):

    def _create_world(self) -> World:

        print("Creating dataset...")

        total_time = 40
        time_delta = .01
        world = World(3, total_time, time_delta)

        # Set initial values for the state
        # Initial rotation matrix
        theta_0 = np.deg2rad(0)
        q_0 = default_rotation.from_rotation_matrix(expm(theta_0 * Vector3([0, 0, 1]).skew()))

        # Initial position
        p_0 = [
            (1.0, 1.0, 0),
            (-2.0, -2.0, 0),
            (-1.5, 3.5, 0),
            (3.5, -1.5, 0)
        ]

        # the true angular velocity input
        ang_vel = Vector3(.5 * 3 * np.array([0, 0, np.sin(.5 * np.pi / 43)]))
        # the true linear velocity input
        lin_vel = Vector3(.5 * np.array([1, 0, 0]))
        vel = Twist(ang_vel, lin_vel)

        # Standard deviations for measurement noise
        ang_vel_noise = 0.01 * np.eye(3)
        lin_vel_noise = 0.05 * np.eye(3)
        landmark_measurement_noise = 0.1 * np.eye(3)
        relative_measurement_noise = 0.1 * np.eye(3)
        communication_noise = 0.001 * np.eye(3)

        for i in range(4):
            name = "R%d" % i
            # True initial position
            p_0_i = Point3D(p_0[i])
            x_0 = Pose(SE3(q_0, p_0_i), "x_0", WorldFrame)

            trajectory = circular_trajectory(x_0, vel, world.num_steps, world.time_delta, name)
            robot = Robot(name, x_0, trajectory, world.rand_int(), world.time_delta)
            robot.set_measurement_errors(ang_vel_noise, lin_vel_noise, landmark_measurement_noise,
                                         relative_measurement_noise)
            world.add_robot(robot)

        landmark_positions = [
            (25, 12, 0),
            (22, -8, 0),
            (3, -7, 0),
            (1, 13, 0),
        ]

        for i in range(4):
            landmark = Landmark("L%d" % i, Point3DReferenced(landmark_positions[i], WorldFrame))
            world.add_landmark(landmark)

        world.set_can_see_landmark(BehzadASCCTest.can_see_landmark)

        world.set_can_see_robot(BehzadASCCTest.can_see_robot)
        world.set_communication_noise(communication_noise)

        return world

    @classmethod
    def can_see_landmark(cls, robot, landmark, time_step):
        # Each robot can only see one landmark. eg. R0 can see L0, R1 can see L1 etc.
        return time_step % 10 == 0 and robot.name[1:] == landmark.name[1:]

    @classmethod
    def can_see_robot(cls, robot_tx: Robot, robot_rx: Robot, time_step):
        # Robots can communicate to those adjacent to each other
        # 0 <-> 1 <-> 2 <-> 3 <-> 0
        connectivity = [
            [0, 0, 1, 1],
            [0, 0, 1, 1],
            [1, 1, 0, 0],
            [1, 1, 0, 0]
        ]

        tx_id = int(robot_tx.name[1:])
        rx_id = int(robot_rx.name[1:])
        # Connected in a loop 0-1-2-3-0
        # return time_step % 10 == 0 and (rx_id == (tx_id + 1) % 4 or rx_id == (tx_id - 1) % 4)
        return time_step % 10 == 1 and connectivity[tx_id][rx_id] == 1

    def _create_filters(self) -> List[FilterMeta]:
        # Initial estimated position
        p_est_0 = [
            (0, 0, 0),
            (-1, -1, 0),
            (0.5, 2.5, 0),
            (2.5, -.5, 0)
        ]

        theta_0 = 0

        filters = []
        targets = []
        estimates = []
        covariances = []

        for i in range(4):
            target = "R%d" % i
            targets.append(target)

            # Estimated initial position
            p_est_0_i = Point3D(p_est_0[i])
            theta_est_0 = theta_0
            q_est_0 = default_rotation.from_rotation_matrix(expm(theta_est_0 * Vector3([0, 0, 1]).skew()))
            x_est_0 = Pose(SE3(q_est_0, p_est_0_i), "x_est_0", WorldFrame)
            estimates.append(x_est_0)
            invcov_est_0 = np.block(
                [[100 * np.diag([1, 1, 1]), np.zeros((3, 3))], [np.zeros((3, 3)), 100 * np.diag([1, 1, 1])]])

            covariances.append(invcov_est_0)
            identifier = "GAME - Covariance"
            process = Process(target=GAME_SE3, args=(identifier, 8000 + 10 * i, [target], x_est_0, invcov_est_0), kwargs={
                'covariance_estimation_method': 'covariance',
            })
            filters.append(FilterMeta([target], identifier, process, 8000 + 10 * i))

            identifier = "GAME - CI"
            process = Process(target=GAME_SE3, args=(identifier, 8001 + 10 * i, [target], x_est_0, invcov_est_0), kwargs={
                'covariance_estimation_method': 'CI',
                'alpha': 0.1
            })
            # filters.append(FilterMeta([target], identifier, process, 8001 + 10 * i))

            identifier = "GAME - Context"
            process = Process(target=GAME_SE3, args=(identifier, 8002 + 10 * i, [target], x_est_0, invcov_est_0), kwargs={
                'covariance_estimation_method': 'context',
            })
            filters.append(FilterMeta([target], identifier, process, 8002 + 10 * i))

        # Create central game filter

        identifier = "Central Game"
        block_cov = scipy.linalg.block_diag(*covariances)
        process = Process(target=Central_GAME_SE3, args=(identifier, 9001, targets, estimates, block_cov))
        filters.append(FilterMeta(targets, identifier, process, 9001))

        identifier = "Central Game Inverse"
        block_cov = scipy.linalg.block_diag(*covariances)
        process = Process(target=Central_GAME_SE3_Inverse, args=(identifier, 9002, targets, estimates, block_cov))
        filters.append(FilterMeta(targets, identifier, process, 9002))
        return filters


if __name__ == '__main__':
    test = BehzadASCCTest()
    # test.run()

    test.post_process()
