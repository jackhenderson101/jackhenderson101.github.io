import sys
from abc import ABC, abstractmethod
from multiprocessing import Process
from time import time, strftime, sleep
from typing import List

from data.simulated.world import World
from src.filters import FilterMeta
from src.post_processing.diagnostics import DiagnosticNode
from src.post_processing.history import HistoryNode, SimulationHistory
from src.post_processing.metrics.estimation_error import estimation_error
from src.post_processing.plots.estimation_error import plot_estimation_error_translation, \
    plot_estimation_error_rotation, plot_individual_estimation_error_translation, plot_estimation_error_translation_ifac
from src.post_processing.plots.trajectory_2D import plot_trajectory_2D
from src.structs.messages import SimulationMeta, Estimate
from src.util.progress_bar import progress_bar
from src.zmq.forwarder import Forwarder
from src.zmq.zmq_node import ZMQNode


class Simulation(ABC):
    """
    A simulation takes in a World and runs through each time step, publishing the required messages to each robot
    running in the simulation
    """

    def __init__(self):
        self.start_time = time()
        self.zmq = ZMQNode()
        self.zmq.subscribe("signals/ready")

        self.world = self._create_world()
        self.filters = self._create_filters()

        self.simulation_name = self.__class__.__name__

        print("Simulation generated in %.2f seconds" % (time() - self.start_time))

    def run(self):

        print("Starting processing threads...")
        t0 = time()

        forwarder_process = Process(target=Forwarder, name='Forwarder')
        forwarder_process.start()

        history_process = Process(target=HistoryNode)
        history_process.start()

        diagnostic_process = Process(target=DiagnosticNode)
        diagnostic_process.start()

        for filt in self.filters:
            filt.process.start()

        self.wait_for_all_processes_to_be_ready(len(self.filters) + 2)
        print("All processes initialised in %.2f seconds" % (time() - t0))

        print("Running Simulation")
        t0 = time()

        meta = SimulationMeta(self.simulation_name, strftime("%Y-%m-%d %H:%M:%S"), self.world.num_steps, self.world.time_delta, self.world.landmarks)
        self.zmq.send('meta', meta)

        for time_step in progress_bar(range(self.world.num_steps), file=sys.stdout):

            for robot in self.world.robots.values():
                measurement = robot.get_velocity_measurement(time_step)
                self.zmq.send(robot.name + "/velocity", measurement)

                ground_truth_pose = Estimate(robot.trajectory[time_step][0], None, time_step)
                self.zmq.send("ground_truth/%s" % robot.name, ground_truth_pose)

            # Perform a filter update if there are any landmark measurements
            for robot in self.world.robots.values():
                for landmark in self.world.landmarks:
                    if self.world.can_see_landmark(robot, landmark, time_step):
                        measurement = robot.get_landmark_measurement(landmark, time_step)
                        # print("Synchronising %s %s %d" % (robot.name, landmark.name, time_step))
                        self.synchronise(self.filters)
                        # print("Synchronising Done")
                        self.zmq.send(robot.name + "/landmark", measurement)
                        for filt in self.filters:
                            if robot.name in filt.targets:
                                # print("waiting for %s %s" % (robot.name, filt.identifier))
                                # Wait for all filters to join
                                filt.zmq_channel.receive()

            # Perform Robot to Robot (R2R) communications
            for robot_tx in self.world.robots.values():
                for robot_rx in self.world.robots.values():
                    if not self.world.can_see_robot(robot_tx, robot_rx, time_step):
                        continue
                    measurement = robot_rx.get_robot_measurement(robot_tx, time_step)
                    self.synchronise(self.filters)
                    for filter_tx in self.filters:
                        if robot_tx.name not in filter_tx.targets:
                            continue
                        for filter_rx in self.filters:
                            if robot_rx.name not in filter_rx.targets or filter_tx.identifier != filter_rx.identifier:
                                continue
                            # print("Message from %s to %s (%s, %s)" % (robot_tx.name, robot_rx.name, filter_tx.identifier, filter_rx.identifier))
                            self.zmq.send_signal("signals/%s/%s/send_r2r_message" % (robot_tx.name, filter_tx.identifier))
                            message = filter_tx.zmq_channel.receive()
                            noisy_message = self.world.add_communication_noise(message)
                            self.zmq.send("%s/%s/r2r_message" % (robot_rx.name, filter_rx.identifier), (noisy_message, measurement))
                            filter_rx.zmq_channel.receive()

        print("Waiting to sync all filters...")
        self.synchronise(self.filters)
        print("Sending stop signal to all nodes")
        self.zmq.send_signal("signals/stop")

        # Wait for all processes to finish processing
        for filt in self.filters:
            filt.process.join()

        print("Simulation finished in %.2f seconds" % (time() - t0))

        history_process.join()
        diagnostic_process.join()

        # Everything is done, we can kill the message forwarder
        forwarder_process.terminate()
        print('Total simulation time: %.2f seconds' % (time() - self.start_time))
        print('###### END OF SIMULATION #####')

    def wait_for_all_processes_to_be_ready(self, expected_processes: int):
        """
        Continuously send out a init signal and wait for all the processes to reply.
        This makes sure that all the processes are ready to receive messages, otherwise some processes might miss the
        first few messages
        """
        processes_started = 0

        print("Waiting for all threads to be ready...")
        while processes_started < expected_processes:
            sleep(0.5)
            self.zmq.send_signal("signals/init")
            while True:
                topic, data = self.zmq.receive(nowait=True)
                if topic is None:
                    break
                if topic.startswith("signals/ready"):
                    processes_started += 1
                    print("%d processes have started" % processes_started)

    def synchronise(self, filters: List[FilterMeta]):
        for filt in filters:
            topic = "signals/%s/%s/synchronise" % (filt.targets[0], filt.identifier)
            self.zmq.send_signal(topic)
        for filt in filters:
            # Wait for all filters to join
            filt.zmq_channel.receive()
        for filt in filters:
            # Release all filters at the same time
            filt.zmq_channel.send_signal()
        for filt in filters:
            # Wait for all filters to join
            filt.zmq_channel.receive()
        for filt in filters:
            # Release all filters at the same time
            filt.zmq_channel.send_signal()

    def post_process(self):

        history = SimulationHistory.load_from_h5('output/%s/simulation_history.h5' % self.simulation_name)

        error = estimation_error(history)

        plot_trajectory_2D(history, "%s/trajectory.pdf" % history.output_dir())

        plot_estimation_error_translation(history, error, "%s/translation_error.pdf" % history.output_dir())
        plot_individual_estimation_error_translation(history, error, "%s/translation_error_R0.pdf" % history.output_dir(), 'R0')
        plot_individual_estimation_error_translation(history, error, "%s/translation_error_R1.pdf" % history.output_dir(), 'R3')

        plot_estimation_error_rotation(history, error,  "%s/rotation_error.pdf" % history.output_dir())

    @abstractmethod
    def _create_world(self) -> World:
        pass

    @abstractmethod
    def _create_filters(self) -> List[FilterMeta]:
        pass
