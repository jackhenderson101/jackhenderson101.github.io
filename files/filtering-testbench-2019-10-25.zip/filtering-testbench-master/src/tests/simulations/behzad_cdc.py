from multiprocessing import Process

import numpy as np

from src.filters.central_game_inverse import Central_GAME_SE3_Inverse
from src.structs.landmark import Landmark
from data.simulated.robot import Robot
from data.simulated.trajectory import circular_trajectory
from data.simulated.world import World
from src.filters import FilterMeta
from src.filters.central_game import Central_GAME_SE3
from src.filters.game import GAME_SE3
from src.geometry.point import Point3D
from src.geometry.pose import Pose, WorldFrame
from src.geometry.point_referenced import Point3DReferenced
from src.geometry.twist import Twist
from src.geometry.SE3 import SE3
from src.geometry.vector3 import Vector3
from src.geometry.rotations import default_rotation
from src.tests.simulations import Simulation


class BehzadCDCTest(Simulation):

    def _create_world(self):
        print("Creating dataset...")

        total_time = 50
        time_delta = .001
        world = World(1, total_time, time_delta)

        # Set initial values for the state

        # Initial rotation matrix
        theta_0 = np.deg2rad(20)
        q_0 = default_rotation.rotz(theta_0)

        # Initial position
        p_0 = Point3D([1, 2, 0])

        # Create pose and twist objects
        x_0 = Pose(SE3(q_0, p_0), "x_0", WorldFrame)

        # Constant z-axis angular velocity
        ang_vel = Vector3(.5 * 3 * np.array([0, 0, np.sin(1 * 2 * np.pi / 18)]))
        # Constant x-axis linear velocity
        lin_vel = Vector3(5 * np.array([1, 0, 0]))
        vel = Twist(ang_vel, lin_vel)

        trajectory = circular_trajectory(x_0, vel, world.num_steps, world.time_delta, 'R1')
        robot = Robot("R1", x_0, trajectory, world.rand_int(), world.time_delta)

        # Standard deviations for measurement noise
        ang_vel_noise = 0.01 * np.eye(3)
        lin_vel_noise = 0.05 * np.eye(3)
        landmark_measurement_noise = 0.1 * np.eye(3)
        robot.set_measurement_errors(ang_vel_noise, lin_vel_noise, landmark_measurement_noise, np.zeros((3, 3)))

        world.add_robot(robot)

        l1 = Landmark("L1", Point3DReferenced([-10, 15, 0], WorldFrame))
        l2 = Landmark("L2", Point3DReferenced([0, 5, 0], WorldFrame))
        world.add_landmark(l1)
        world.add_landmark(l2)

        world.set_can_see_landmark(BehzadCDCTest.can_see_landmark)

        return world

    @classmethod
    def can_see_landmark(cls, robot, landmark, time_step):
        return time_step % 1000 == 0

    def _create_filters(self):
        filters = []

        theta_0 = np.deg2rad(20)
        p_0 = Point3D([1, 2, 0])

        theta_est_0 = theta_0 + np.deg2rad(25)
        q_est_0 = default_rotation.rotz(theta_est_0)
        p_est_0 = p_0 + Vector3([+2.0, -4.0, 0])

        x_est_0 = Pose(SE3(q_est_0, p_est_0), "x_est_0", WorldFrame)

        information_est_0 = np.block(
            [[10000 * np.diag([1, 1, 1]), np.zeros((3, 3))], [np.zeros((3, 3)), 10000 * np.diag([1, 1, 1])]])

        identifier = "GAME - Zero Connection"
        process = Process(target=GAME_SE3, args=(identifier, 8001, ["R1"], x_est_0, information_est_0), kwargs={
            'connection_type': 'zero'
        })
        filters.append(FilterMeta(["R1"], identifier, process, 8001))

        identifier = "GAME - Cartan Connection"
        process = Process(target=GAME_SE3, args=(identifier, 8002, ["R1"], x_est_0, information_est_0), kwargs={
            'connection_type': 'cartan'
        })
        filters.append(FilterMeta(["R1"], identifier, process, 8002))

        identifier = "Central Game - Test"
        process = Process(target=Central_GAME_SE3, args=(identifier, 8003, ["R1"], [x_est_0], information_est_0))
        filters.append(FilterMeta(["R1"], identifier, process, 8003))

        # identifier = "Central Game - Inverse"
        # process = Process(target=Central_GAME_SE3_Inverse, args=(identifier, 8004, ["R1"], [x_est_0], information_est_0))
        # filters.append(FilterMeta(["R1"], identifier, process, 8004))

        return filters


if __name__ == '__main__':

    test = BehzadCDCTest()
    test.run()
    test.post_process()
