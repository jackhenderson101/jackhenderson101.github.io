import matplotlib.pyplot as plt
import seaborn

from src.post_processing.history import SimulationHistory


def plot_estimation_error_translation(history: SimulationHistory, errors, filename: str):

    time_values = history.meta.time_delta * range(history.meta.num_steps)

    plt.figure()

    for (filter_name, error_data) in errors.items():
        plt.plot(time_values, error_data['mean']['translation'], label=filter_name)

    plt.legend(loc='upper left')
    plt.title("Average translation error")
    plt.xlabel("Time (s)")
    plt.xlim(xmin=0)
    plt.ylabel("Average translation error (m)")
    plt.ylim(ymin=0, ymax=0.5)
    plt.savefig(filename, bbox_inches='tight')
    plt.show()


def plot_estimation_error_translation_ifac(history: SimulationHistory, errors, filename: str):
    seaborn.set_style('white', {'axes.axisbelow': True,
                                'axes.edgecolor': '.8',
                                'axes.facecolor': 'white',
                                'axes.grid': True,
                                'axes.labelcolor': '.15',
                                'axes.spines.bottom': True,
                                'axes.spines.left': True,
                                'axes.spines.right': True,
                                'axes.spines.top': True,
                                'figure.facecolor': 'white',
                                'font.family': ['sans-serif'],
                                'font.sans-serif': ['Arial',
                                                    'DejaVu Sans',
                                                    'Liberation Sans',
                                                    'Bitstream Vera Sans',
                                                    'sans-serif'],
                                'grid.color': '.8',
                                'grid.linestyle': '-',
                                'image.cmap': 'rocket',
                                'lines.solid_capstyle': 'round',
                                'patch.edgecolor': 'w',
                                'patch.force_edgecolor': True,
                                'text.color': '.15',
                                'xtick.bottom': False,
                                'xtick.color': '.15',
                                'xtick.direction': 'out',
                                'xtick.top': False,
                                'ytick.color': '.15',
                                'ytick.direction': 'out',
                                'ytick.left': False,
                                'ytick.right': False})

    time_values = history.meta.time_delta * range(history.meta.num_steps)

    plt.figure(figsize=(8, 4))
    linestyles = {
        'Central GAME': '-',
        'Decoupled GAME': ':',
        'Zamani and Hunjet (2019)': '-'
    }

    for (filter_name, error_data) in errors.items():
        plt.plot(time_values, error_data['mean']['translation'], label=filter_name, linestyle=linestyles[filter_name])

    plt.legend(loc='upper left')
    plt.xlabel("Time (s)")
    plt.xlim(xmin=0, xmax=30)
    plt.ylabel("Average translation error (m)")
    plt.ylim(ymin=0, ymax=0.4)
    plt.savefig(filename, bbox_inches='tight')
    plt.show()


def plot_individual_estimation_error_translation(history: SimulationHistory, errors, filename: str, robot_name: str):

    time_values = history.meta.time_delta * range(history.meta.num_steps)

    plt.figure()

    for (filter_name, error_data) in errors.items():
        plt.plot(time_values, error_data['robots'][robot_name]['translation'], label=filter_name)

    plt.legend(loc='upper right')
    plt.title("Translation error for %s" % robot_name)
    plt.xlabel("Time (s)")
    plt.xlim((0, time_values[-1]))
    plt.ylabel("Average translation error (m)")
    plt.ylim(ymin=0)
    plt.savefig(filename, bbox_inches='tight')
    plt.show()


def plot_estimation_error_rotation(history: SimulationHistory, errors, filename: str):
    time_values = history.meta.time_delta * range(history.meta.num_steps)

    plt.figure()

    for (filter_name, error_data) in errors.items():
        plt.plot(time_values, error_data['mean']['rotation'], label=filter_name)

    plt.legend(loc='upper right')
    plt.title("Average rotation error")
    plt.xlabel("Time (s)")
    plt.xlim((0, time_values[-1]))

    plt.ylabel("Average rotation error (rad)")
    plt.savefig(filename, bbox_inches='tight')
    plt.show()

