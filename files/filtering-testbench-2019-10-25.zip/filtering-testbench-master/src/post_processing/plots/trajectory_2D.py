import matplotlib.pyplot as plt

from src.post_processing.history import SimulationHistory


def plot_trajectory_2D(history: SimulationHistory, filename: str):
    plt.figure()
    plot_landmarks(history.meta.landmarks)
    plot_ground_truth(history.ground_truth)
    plot_estimates(history.filters)

    # plt.legend(loc='upper right')

    plt.title("Ground Truth and Estimated Trajectories")
    plt.xlabel('x (m)')
    plt.ylabel('y (m)')

    plt.savefig(filename, bbox_inches='tight')
    plt.show()


def plot_landmarks(landmarks):
    for landmark in landmarks:
        plt.plot(landmark.location.xyz[0], landmark.location.xyz[1], '^', label='Landmark %s' % landmark.name)


def plot_ground_truth(ground_truth):

    for (robot_name, trajectory) in ground_truth.items():
        ground_truth_x = trajectory[:, 0, 3]
        ground_truth_y = trajectory[:, 1, 3]
        plt.plot(ground_truth_x, ground_truth_y, label="%s Ground Truth" % robot_name, markevery=[0, 1])


def plot_estimates(filters):
    for (filter_name, robots) in filters.items():
        for (robot_name, estimate) in robots.items():
            estimate_x = estimate[:, 0, 3]
            estimate_y = estimate[:, 1, 3]
            plt.plot(estimate_x, estimate_y, '-.', label='%s: %s' % (filter_name, robot_name), markevery=[0, 1])
