from abc import ABC


class Plot(ABC):

    pass
