import numpy as np

from src.post_processing.history import SimulationHistory
from src.geometry.rotations import RotationMatrix


def estimation_error(history: SimulationHistory):

    errors = {}

    for (filt, robots) in history.filters.items():
        errors[filt] = {'summary': {}, 'mean': None, 'robots': {}}
        for (robot, estimate) in robots.items():
            errors[filt]['robots'][robot] = {}

            ground_truth = history.ground_truth[robot]
            translation_error = np.linalg.norm(estimate[:, 0:3, 3] - ground_truth[:, 0:3, 3], axis=1)

            rotation_error = np.zeros(translation_error.shape)
            for i in range(len(rotation_error)):
                rotation_error[i] = (RotationMatrix(estimate[i, 0:3, 0:3]).inverse() * RotationMatrix(ground_truth[i, 0:3, 0:3])).angle_from_zero()

            errors[filt]['robots'][robot] = {
                'translation': translation_error,
                'rotation': rotation_error
            }

        translation_errors = list(map(lambda x: x['translation'], errors[filt]['robots'].values()))
        rotation_errors = list(map(lambda x: x['rotation'], errors[filt]['robots'].values()))

        errors[filt]['mean'] = {
            'translation': np.mean(translation_errors, axis=0),
            'rotation':  np.mean(rotation_errors, axis=0)
        }
        errors[filt]['summary'] = {
            'translation': {
                'mean': np.mean(translation_errors),
                'max': np.max(translation_errors),
                'min': np.min(translation_errors)
            },
            'rotation': {
                'mean': np.mean(rotation_errors),
                'max': np.max(rotation_errors),
                'min': np.min(rotation_errors)
            }
        }
    return errors
