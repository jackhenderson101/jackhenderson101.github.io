"""
A metric represents some way to measure the error between the true state of the system, and the state estimated by the
filters
"""
from abc import ABC


class Metric(ABC):
    pass
