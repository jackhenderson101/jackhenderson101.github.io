

class SummaryStatistics:

    def __init__(self, num_steps, time_delta, filters):
        pass
