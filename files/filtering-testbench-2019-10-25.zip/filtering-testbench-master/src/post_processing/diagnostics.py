import os
import h5py
import numpy as np
from typing import Dict

from src.structs.landmark import Landmark
from src.geometry.point_referenced import Point3DReferenced
from src.structs.messages import Estimate, SimulationMeta, DiagnosticData
from src.zmq.zmq_node import ZMQNode


class DiagnosticHistory:
    """
    The simulation history stores all of the information about a single simulation, including:
    * ground truth trajectories
    * Estimated trajectories from each filter
    * Landmark positions
    * Metadata about the simulation

    The simulation history should contain all information required to do any post-processing and can be saved to a HDF5
    file and reloaded at a later time.
    """

    def __init__(self, meta: SimulationMeta = None):
        self.data = {}
        self.meta = meta

    def output_dir(self) -> str:
        return "output/%s" % self.meta.simulation_name

    def add_data(self, topic, data: DiagnosticData):

        if topic not in self.data:
            self.data[topic] = np.full((*data.data.shape, self.meta.num_steps), np.nan)

        index = [slice(None)]*(data.data.ndim+1)
        index[-1] = data.time_step
        self.data[topic][index] = data.data

    def save_to_h5(self, filename: str):
        print("Saving simulation history to %s" % filename)
        directory = os.path.dirname(filename)
        if not os.path.exists(directory):
            os.makedirs(directory)

        with h5py.File(filename, 'w') as f:

            for (key, val) in self.meta.__dict__.items():
                if key == "landmarks":
                    continue
                f.attrs[key] = val

            for (key, val) in self.data.items():
                f.create_dataset(key, data=val, compression='gzip')


        print("Diagnostics saved")

    # @classmethod
    # def load_from_h5(cls, filename):
    #     ground_truth = {}
    #     filters = {}
    #     landmarks = []
    #
    #     with h5py.File(filename, 'r') as f:
    #         for (robot, data) in f['ground_truth'].items():
    #             np_data = np.zeros(data.shape)
    #             data.read_direct(np_data)
    #             ground_truth[robot] = np_data
    #
    #         for (filt, robots) in f['filters'].items():
    #             filters[filt] = {}
    #             for (robot, data) in robots.items():
    #                 np_data = np.zeros(data.shape)
    #                 data.read_direct(np_data)
    #                 filters[filt][robot] = np_data
    #
    #         for (landmark_name, landmark_pos) in f['landmarks'].items():
    #             landmarks.append(Landmark(landmark_name, Point3DReferenced(landmark_pos)))
    #
    #         meta = SimulationMeta(landmarks=landmarks, **f.attrs)
    #
    #     history = SimulationHistory(ground_truth, filters, meta)
    #     return history


class DiagnosticNode:
    """
    The HistoryNode listens to all filter estimates and ground truth messages and builds up a SimulationHistory so it
    can be saved to file at the end of a simulation.
    """

    def __init__(self):

        self.zmq = ZMQNode()
        self.zmq.subscribe("diagnostics/")

        self.zmq.receive()
        self.zmq.send_signal("signals/ready/diagnostics")

        self.diag = DiagnosticHistory()

        self.run()

    def run(self):

        while True:
            topic, data = self.zmq.receive()

            if topic == "signals/stop":
                self.on_stop()
                break


            if isinstance(data, SimulationMeta):
                self.diag.meta = data
            elif isinstance(data, DiagnosticData):
                self.diag.add_data(topic, data)

    def on_stop(self):
        filename = "%s/diagnostic_data.h5" % self.diag.output_dir()
        self.diag.save_to_h5(filename)
