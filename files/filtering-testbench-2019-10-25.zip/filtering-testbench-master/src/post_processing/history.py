import os
import h5py
import numpy as np
from typing import Dict

from src.structs.landmark import Landmark
from src.geometry.point_referenced import Point3DReferenced
from src.structs.messages import Estimate, SimulationMeta
from src.zmq.zmq_node import ZMQNode


class SimulationHistory:
    """
    The simulation history stores all of the information about a single simulation, including:
    * ground truth trajectories
    * Estimated trajectories from each filter
    * Landmark positions
    * Metadata about the simulation

    The simulation history should contain all information required to do any post-processing and can be saved to a HDF5
    file and reloaded at a later time.
    """

    def __init__(self, ground_truth: Dict[str, np.ndarray] = {}, filters: Dict[str, Dict[str, np.ndarray]] = {}, meta: SimulationMeta = None):
        self.ground_truth = ground_truth
        self.filters = filters
        self.meta = meta

    def output_dir(self) -> str:
        return "output/%s" % self.meta.simulation_name

    def add_ground_truth(self, robot_id: str, time_step: int, pose: np.ndarray):
        if robot_id not in self.ground_truth:
            self.ground_truth[robot_id] = np.zeros((self.meta.num_steps, 4, 4))

        self.ground_truth[robot_id][time_step, :, :] = pose

    def add_filter_estimate(self, filter_id: str, robot_id: str, time_step: int, pose: np.ndarray):
        if filter_id not in self.filters:
            self.filters[filter_id] = {}
        if robot_id not in self.filters[filter_id]:
            self.filters[filter_id][robot_id] = np.zeros((self.meta.num_steps, 4, 4))

        self.filters[filter_id][robot_id][time_step, :, :] = pose

    def save_to_h5(self, filename: str):
        print("Saving simulation history to %s" % filename)
        directory = os.path.dirname(filename)
        if not os.path.exists(directory):
            os.makedirs(directory)

        with h5py.File(filename, 'w') as f:

            for (key, val) in self.meta.__dict__.items():
                if key == "landmarks":
                    continue
                f.attrs[key] = val

            filter_group = f.create_group('filters')
            for (filt, robots) in self.filters.items():
                group = filter_group.create_group(filt)
                for (robot, data) in robots.items():
                    group.create_dataset(robot, data=data, compression='gzip')

            gt_group = f.create_group('ground_truth')

            for (robot, data) in self.ground_truth.items():
                gt_group.create_dataset(robot, data=data, compression='gzip')

            landmark_group = f.create_group('landmarks')
            for landmark in self.meta.landmarks:
                landmark_group.create_dataset(landmark.name, data=landmark.location.xyz)

        print("Simulation saved")

    @classmethod
    def load_from_h5(cls, filename):
        ground_truth = {}
        filters = {}
        landmarks = []

        with h5py.File(filename, 'r') as f:
            for (robot, data) in f['ground_truth'].items():
                np_data = np.zeros(data.shape)
                data.read_direct(np_data)
                ground_truth[robot] = np_data

            for (filt, robots) in f['filters'].items():
                filters[filt] = {}
                for (robot, data) in robots.items():
                    np_data = np.zeros(data.shape)
                    data.read_direct(np_data)
                    filters[filt][robot] = np_data

            for (landmark_name, landmark_pos) in f['landmarks'].items():
                landmarks.append(Landmark(landmark_name, Point3DReferenced(landmark_pos)))

            meta = SimulationMeta(landmarks=landmarks, **f.attrs)

        history = SimulationHistory(ground_truth, filters, meta)
        return history


class HistoryNode:
    """
    The HistoryNode listens to all filter estimates and ground truth messages and builds up a SimulationHistory so it
    can be saved to file at the end of a simulation.
    """

    def __init__(self):

        self.zmq = ZMQNode()
        self.zmq.subscribe("filter_estimate/")
        self.zmq.subscribe("ground_truth/")

        self.zmq.receive()
        self.zmq.send_signal("signals/ready/history")

        self.history = SimulationHistory()

        self.run()

    def run(self):

        while True:
            topic, data = self.zmq.receive()

            if topic == "signals/stop":
                self.on_stop()
                break

            if isinstance(data, Estimate):
                self.on_estimate(topic, data)
            elif isinstance(data, SimulationMeta):
                self.history.meta = data

    def on_estimate(self, topic: str, data: Estimate):
        topic_parts = topic.split('/')
        if topic_parts[0] == 'ground_truth':
            robot_id = topic_parts[1]
            self.history.add_ground_truth(robot_id, data.time_step, data.state_estimate.transform.as_matrix())

        else:
            filter_id = topic_parts[1]
            robot_id = topic_parts[2]
            self.history.add_filter_estimate(filter_id, robot_id, data.time_step, data.state_estimate.transform.as_matrix())

    def on_stop(self):
        filename = "%s/simulation_history.h5" % self.history.output_dir()
        self.history.save_to_h5(filename)
