from __future__ import annotations

from abc import ABC, abstractmethod

import numpy as np
import quaternion as quat
from scipy.linalg import expm

from src.geometry.point import Point3D
from src.geometry.vector3 import Vector3
from src.util.geometry import exponential_map


class Rotation(ABC):
    """
    An abstract rotation class. Can either be represented by a quaternion or by a 3x3 rotation matrix
    """

    @abstractmethod
    def as_matrix(self) -> np.ndarray:
        """ Return a raw 3x3 numpy matrix representing the rotation"""
        pass

    @abstractmethod
    def as_quaternion(self) -> quat.quaternion:
        """ Return the quaternion object (from the quaternion library) representing the rotation"""
        pass

    @abstractmethod
    def inverse(self) -> Rotation:
        pass

    @abstractmethod
    def integrate_velocity(self, angular_velocity: Vector3, dt: float) -> Rotation:
        pass

    def angle_from_zero(self):
        return np.arccos(0.5 * (np.trace(self.as_matrix()) - 1))

    def __eq__(self, other):
        if isinstance(other, Rotation):
            return np.allclose(self.as_matrix(), other.as_matrix())
        return NotImplemented

    @abstractmethod
    def __mul__(self, other):
        """ Multiply two rotations together, or multiply a rotation with a point """
        pass

    @abstractmethod
    def __str__(self):
        pass

    @classmethod
    @abstractmethod
    def from_quaternion(cls, q) -> Rotation:
        pass

    @classmethod
    @abstractmethod
    def from_rotation_matrix(cls, rot) -> Rotation:
        pass

    @staticmethod
    @abstractmethod
    def identity() -> Rotation:
        pass

    @staticmethod
    @abstractmethod
    def rotx(angle: float) -> Rotation:
        """ Create a rotation object representing a rotation of `angle` radians in the x-axis """
        pass

    @staticmethod
    @abstractmethod
    def roty(angle: float) -> Rotation:
        """ Create a rotation object representing a rotation of `angle` radians in the y-axis """
        pass

    @staticmethod
    @abstractmethod
    def rotz(angle: float) -> Rotation:
        """ Create a rotation object representing a rotation of `angle` radians in the z-axis """
        pass


class Quaternion(Rotation):

    def __init__(self, quaternion: quat.quaternion):
        assert(isinstance(quaternion, quat.quaternion))
        self.__quat = quaternion

    def as_matrix(self) -> np.ndarray:
        return quat.as_rotation_matrix(self.__quat)

    def as_quaternion(self) -> quat.quaternion:
        return self.__quat

    def inverse(self) -> Rotation:
        return Quaternion(self.__quat.inverse())

    def integrate_velocity(self, angular_velocity: Vector3, dt: float) -> Quaternion:
        assert isinstance(angular_velocity, Vector3)

        # From Eqn 3 in Zamani and Trumpf, 2019
        A = np.zeros((4, 4))
        A[1:4, 0] = angular_velocity.xyz
        A[0, 1:4] = - angular_velocity.xyz
        A[1:4, 1:4] = - angular_velocity.skew()

        q_t = expm(dt * 0.5 * A) @ quat.as_float_array(self.__quat)
        return Quaternion(quat.from_float_array(q_t))

    def __mul__(self, other):
        if isinstance(other, Rotation):
            return Quaternion(self.__quat * other.as_quaternion())
        elif isinstance(other, Point3D):
            return Point3D(quat.rotate_vectors(self.__quat, other.xyz))
        else:
            return NotImplemented

    def __str__(self):
        return str(self.__quat)

    def __repr__(self):
        return repr(self.__quat)

    @classmethod
    def from_quaternion(cls, q) -> Rotation:
        return cls(q)

    @classmethod
    def from_rotation_matrix(cls, rot) -> Rotation:
        return cls(quat.from_rotation_matrix(rot))

    @staticmethod
    def identity() -> Rotation:
        return Quaternion(quat.one)

    @staticmethod
    def rotx(angle: float) -> Rotation:
        return Quaternion(quat.from_rotation_vector([angle, 0, 0]))

    @staticmethod
    def roty(angle: float) -> Rotation:
        return Quaternion(quat.from_rotation_vector([0, angle, 0]))

    @staticmethod
    def rotz(angle: float) -> Rotation:
        return Quaternion(quat.from_rotation_vector([0, 0, angle]))


class RotationMatrix(Rotation):

    def __init__(self, rotation: np.ndarray):
        assert rotation.shape == (3, 3)
        self.__rot = rotation

    def as_matrix(self) -> np.ndarray:
        return self.__rot

    def as_quaternion(self) -> quat.quaternion:
        return quat.from_rotation_matrix(self.__rot)

    def inverse(self) -> Rotation:
        return RotationMatrix(self.__rot.T)

    def integrate_velocity(self, angular_velocity: Vector3, dt: float) -> RotationMatrix:

        return RotationMatrix(self.__rot @ exponential_map(dt * angular_velocity.xyz))

    def __mul__(self, other):
        if isinstance(other, Rotation):
            return RotationMatrix(self.__rot @ other.as_matrix())
        elif isinstance(other, Point3D):
            return Point3D(self.__rot @ other.xyz)
        else:
            return NotImplemented

    def __str__(self):
        return "Rotation Matrix: " + str(self.__rot)

    def __repr__(self):
        return repr(self.__rot)

    @classmethod
    def from_quaternion(cls, q) -> Rotation:
        return RotationMatrix(quat.as_rotation_matrix(q))

    @classmethod
    def from_rotation_matrix(cls, rot) -> Rotation:
        return cls(rot)

    @staticmethod
    def identity():
        return RotationMatrix(np.eye(3))

    @staticmethod
    def rotx(angle: float) -> Rotation:
        c = np.cos(angle)
        s = np.sin(angle)

        return RotationMatrix(np.array([
            [1, 0,  0],
            [0, c, -s],
            [0, s,  c]
        ]))

    @staticmethod
    def roty(angle: float) -> Rotation:
        c = np.cos(angle)
        s = np.sin(angle)

        return RotationMatrix(np.array([
            [c,  0, s],
            [0,  1, 0],
            [-s, 0, c]
        ]))

    @staticmethod
    def rotz(angle: float) -> Rotation:
        c = np.cos(angle)
        s = np.sin(angle)

        return RotationMatrix(np.array([
            [c, -s, 0],
            [s,  c, 0],
            [0,  0, 1]
        ]))


# TODO: is there a better way to do this?
default_rotation = RotationMatrix
# default_rotation = Quaternion
