import numpy as np

from src.geometry.point import Point3D
from src.geometry.rotations import Rotation, default_rotation


class SE3:
    """
    Represents an element of the Special Euclidean (3) group.
    """

    def __init__(self, rotation: Rotation, translation: Point3D):
        assert(isinstance(rotation, Rotation))
        assert(isinstance(translation, Point3D))

        self.rotation = rotation
        self.translation = translation

    def as_matrix(self) -> np.ndarray:
        """
        Generate the 4x4 homogeneous transformation matrix

        | R R R t |
        | R R R t |
        | R R R t |
        | 0 0 0 1 |
        """
        R = self.rotation.as_matrix()
        t = self.translation.column_vec()
        return np.block([[R, t], [0, 0, 0, 1]])

    def inverse(self):
        R = self.rotation.inverse()
        t = - (R * self.translation)
        return SE3(R, t)

    @classmethod
    def identity(cls):
        """ Return the pose of the origin (The identity matrix) """
        return cls(default_rotation.identity(), Point3D.zero())

    @staticmethod
    def from_matrix(T: np.ndarray):
        """ Create a Pose object from a 4x4 homogeneous transformation matrix """
        assert T.shape == (4, 4)
        assert np.all(T[3, :] == [0, 0, 0, 1])

        R = default_rotation.from_rotation_matrix(T[0:3, 0:3])
        t = Point3D(T[0:3, 3])

        return SE3(R, t)

    def __eq__(self, other):
        if isinstance(other, SE3):
            return self.translation == other.translation and self.rotation == other.rotation
        else:
            return NotImplemented

    def __mul__(self, other):
        if isinstance(other, SE3):
            R = self.rotation * other.rotation
            t = self.rotation * other.translation + self.translation
            return SE3(R, t)
        elif isinstance(other, Point3D):
            return self.rotation * other + self.translation
        else:
            return NotImplemented

    def __str__(self):
        return "%s, %s" % (self.rotation, self.translation)
