import copy
from typing import Union

import numpy as np

from src.util import geometry


class Vector3:
    """ Represents an abstract 3 Vector, typically x,y,z coordinates in R3"""

    __array_priority__ = 100  # Allows us to rmul with numpy matrices

    def __init__(self, xyz: Union[np.ndarray, list, tuple]):
        """
        A point can either be created by:
        Point3D((1,2,3))
        Point3D([1,2,3])
        Point3D(np.array([1,2,3])
        """
        if not isinstance(xyz, np.ndarray):
            xyz = np.array(xyz)
        assert xyz.shape == (3,)
        self.xyz: np.ndarray = xyz

    @classmethod
    def zero(cls):
        return cls(np.zeros(3))

    def column_vec(self) -> np.ndarray:
        """ Return a 2-D numpy column vector"""
        return self.xyz.reshape(-1, 1)

    def row_vec(self) -> np.ndarray:
        """ Return a 2-D numpy row vector"""
        return self.xyz.reshape(1, -1)

    def skew(self) -> np.ndarray:
        """ See definition in utils.skew """
        return geometry.skew(self.xyz)

    def l2_norm(self):
        """Compute the L2 Norm of the vector"""
        return np.linalg.norm(self.xyz)

    def homog(self):
        """ Return the homogeneous coordinates of the vector. ie. [x, y, z, 1] """
        return np.append(self.xyz, [1]).reshape(-1, 1)

    def __neg__(self):
        new = copy.copy(self)
        new.xyz = - self.xyz
        return new

    def __sub__(self, other):
        return self + (-other)

    def __add__(self, other):
        if isinstance(other, Vector3):
            new = copy.copy(self)
            new.xyz = self.xyz + other.xyz
            return new
        else:
            return NotImplemented

    def __rmul__(self, other):
        if isinstance(other, np.ndarray) and other.shape == (3, 3):
            new = copy.copy(self)
            new.xyz = other @ self.xyz
            return new
        if isinstance(other, float) or isinstance(other, int):
            new = copy.copy(self)
            new.xyz = other * self.xyz
            return new
        else:
            return NotImplemented

    def __eq__(self, other):
        return np.allclose(self.xyz, other.xyz)

    def __abs__(self):
        return np.abs(self.xyz)
