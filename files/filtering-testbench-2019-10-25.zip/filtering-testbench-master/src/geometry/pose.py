from __future__ import annotations

from typing import Union

from src.geometry.SE3 import SE3
from src.geometry.twist import Twist


class Pose:
    """
    Represents the pose (rotation and translation) of an object or frame in 3D Space relative to a reference frame.

    Internal representation is a quaternion for the rotation and a 3 vector for the translation
    """

    def __init__(self, transform: SE3, name: str, reference_frame: Union[Pose, None]):
        self.transform = transform
        self.reference = reference_frame
        self.name = name
        self.inertial = (reference_frame is None)

    @staticmethod
    def inertial_frame(name):
        return Pose(SE3.identity(), name, None)

    def __str__(self):
        if self.inertial:
            return self.name

        return '%s(%s) w.r.t %s' % (self.name, str(self.transform), self.reference.name)

    def integrate_twist(self, twist: Twist, time: float, new_name: str) -> Pose:
        """
        Numerically forward integrate the twist data based on the current pose.
        E.g. if the twist represents a velocity measurement, predict where the pose will be after time t.
        """
        R = self.transform.rotation.integrate_velocity(twist.angular, time)

        t = self.transform.translation + time * (self.transform.rotation.as_matrix() * twist.linear)

        return Pose(SE3(R, t), new_name, self.reference)


WorldFrame = Pose(SE3.identity(), 'World', None)
