from __future__ import annotations

import numpy as np

from src.geometry.vector3 import Vector3


class Twist:
    """
    Represents an angular and linear velocity (i.e \frac{se}(3))

    Internally represented as two 3-vectors representing the angular and linear velocities respectively
    """

    def __init__(self, angular: Vector3, linear: Vector3):
        assert isinstance(angular, Vector3), "Angular velocity must be a 3-vector"
        assert isinstance(linear, Vector3), "Linear velocity must be a 3-vector"
        self.angular = angular
        self.linear = linear

    @staticmethod
    def zero() -> Twist:
        """ Return an object representing zero angular and linear velocity """
        return Twist(Vector3.zero(), Vector3.zero())

    def as_matrix(self) -> np.ndarray:
        """
        Generate the 4x4 se(3) twist matrix

        | R R R t |
        | R R R t |
        | R R R t |
        | 0 0 0 0 |
        """
        R = self.angular.skew()
        t = self.linear.column_vec()
        return np.block([[R, t], [0, 0, 0, 0]])

    @staticmethod
    def from_vector(v) -> Twist:
        assert v.shape == (6,), "Twist vector must be a 6-vector"
        return Twist(Vector3(v[0:3]), Vector3(v[3:6]))

    def as_vector(self) -> np.ndarray:
        return np.concatenate((self.angular.xyz, self.linear.xyz))
