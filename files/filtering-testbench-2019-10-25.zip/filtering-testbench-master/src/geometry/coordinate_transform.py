from __future__ import annotations

from typing import Union

from src.geometry.pose import Pose
from src.geometry.point_referenced import Point3DReferenced
from src.geometry.SE3 import SE3


class CoordinateTransform:
    """
    Represents an operation that transforms the representation of a point, P, represented in the coordinates
    of frame 'frame from' into the coordinates used by frame 'frame_to'.
    """

    def __init__(self, transform: SE3, frame_from: Pose, frame_to: Pose):
        self.transform = transform
        self.frame_from = frame_from
        self.frame_to = frame_to

    @staticmethod
    def calculate_transform(frame_from: Pose, frame_to: Pose) -> CoordinateTransform:
        """
        Calculate the required coordinate transform to go from one pose to another. The two poses must be linked by a
        common inertial frame

        :return: A CoordinateTransform object from `frame_from` to `frame_to`
        """

        t_from_base = CoordinateTransform.transform_to_inertial(frame_from)
        t_to_base = CoordinateTransform.transform_to_inertial(frame_to)

        if t_from_base.frame_to.name != t_to_base.frame_to.name:
            raise Exception("Frames are not referenced in the same inertial frame. "
                            "Cannot compute a transformation from %s to %s" % (frame_from.name, frame_to.name))
        return t_to_base.inverse() * t_from_base

    @staticmethod
    def transform_to_inertial(pose: Pose) -> CoordinateTransform:
        """
        Calculate the transformation from the specified pose to the inertial frame (typically the world frame)
        """
        if pose.inertial:
            return CoordinateTransform(SE3.identity(), pose, pose)
        if pose.reference.inertial:
            return CoordinateTransform(pose.transform, pose, pose.reference)
        return CoordinateTransform.transform_to_inertial(pose.reference) * CoordinateTransform(pose.transform, pose, pose.reference)

    def inverse(self) -> CoordinateTransform:
        """ Calculate the inverse coordinate transformation """
        return CoordinateTransform(self.transform.inverse(), frame_from=self.frame_to, frame_to=self.frame_from)

    def __mul__(self, other: Union[CoordinateTransform, Point3DReferenced]):
        if isinstance(other, CoordinateTransform):
            assert self.frame_from.name == other.frame_to.name, "Cannot multiply coordinate transformations: (%s) and (%s)" % (self, other)
            return CoordinateTransform(self.transform * other.transform, other.frame_from, self.frame_to)

        if isinstance(other, Point3DReferenced):
            assert other.reference.name == self.frame_from.name, "Cannot apply transform (%s) to Point (%s)" % (self, other)
            new_point = self.transform * other
            return Point3DReferenced(new_point.xyz, self.frame_to)

        return NotImplemented

    def __eq__(self, other):
        if isinstance(other, CoordinateTransform):
            return \
                self.transform == other.transform and \
                self.frame_from.name == other.frame_from.name and \
                self.frame_to == other.frame_to
        else:
            return NotImplemented

    def __str__(self):
        return "Coordinate Transform from %s to %s: (%s)" % (self.frame_from.name, self.frame_to.name, self.transform)
