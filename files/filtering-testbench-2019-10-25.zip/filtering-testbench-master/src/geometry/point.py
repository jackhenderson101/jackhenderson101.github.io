from __future__ import annotations

from src.geometry.vector3 import Vector3


class Point3D(Vector3):
    """ Represents a point in 3D space with coordinates X,Y,Z """

    def __repr__(self):
        return "Point3D(" + repr(self.xyz.tolist()) + ')'

    # def __add__(self, other: Union[Point3D, np.ndarray]):
    #     if isinstance(other, Point3D):
    #         return Point3D(self.xyz + other.xyz)
    #     if isinstance(other, np.ndarray) and other.shape == (3,):
    #         return Point3D(self.xyz + other)
    #     return NotImplemented
    #
    #
