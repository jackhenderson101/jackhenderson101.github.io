from typing import Union

import numpy as np

from src.geometry.point import Point3D
from src.geometry.pose import WorldFrame, Pose
from src.geometry.vector3 import Vector3


class Point3DReferenced(Point3D):

    def __init__(self, xyz: Union[np.ndarray, list, tuple], reference: Pose = WorldFrame):
        super().__init__(xyz)
        self.reference = reference

    def __str__(self):
        return "Point3D %s w.r.t %s" % (self.xyz.tolist(), self.reference.name)

    def __add__(self, other: Union[Point3D, np.ndarray]):
        if isinstance(other, Point3DReferenced):
            assert self.reference.name == other.reference.name
            return Point3DReferenced(self.xyz + other.xyz, self.reference)
        if isinstance(other, Vector3):
            return Point3DReferenced(self.xyz + other.xyz, self.reference)
        if isinstance(other, np.ndarray) and other.shape == (3,):
            return Point3DReferenced(self.xyz + other, self.reference)
        return NotImplemented

    def deref(self) -> Point3D:
        """ Remove the reference frame for the point """
        return Point3D(self.xyz)
