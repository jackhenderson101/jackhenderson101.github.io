import traceback
from typing import List

import cProfile
import numpy as np
import scipy

from data.simulated.robot import marker_point
from src.filters import Filter
from src.filters.abstract_game import Abstract_GAME
from src.geometry.pose import Pose, WorldFrame
from src.geometry.point_referenced import Point3DReferenced
from src.geometry.coordinate_transform import CoordinateTransform
from src.geometry.twist import Twist
from src.structs.messages import VelocityMeasurement, LandmarkMeasurement, RobotMeasurement, R2RMessage, Estimate, \
    DiagnosticData
from src.util.geometry import is_positive_definite, symmetric_projection as P_s, trace_projection as P_t, \
    se3_projection as P, skew, se3_vex
from scipy.linalg import expm
from numpy.linalg import inv


def F(v):
    x = np.zeros((4, 6))
    x[0:3, 0:3] = -skew(v[0:3, 0])
    x[0:3, 3:6] = np.eye(3)
    return x


def G(v):
    x = np.zeros((4, 6))
    x[0:3, 0:3] = skew(v[0:3, 0])
    x[3, 3:6] = v[0:3, 0]
    return x



class Central_GAME_SE3_Inverse(Abstract_GAME):
    """
    Implements the Centralised Geometric Approximate Minimum Energy Filter on the SE3 Group
    Using the cartan connection.
    """

    def __init__(self, identifier: str, sync_port: int, targets: List[str], initial_states: List[Pose],
                 initial_information):

        super().__init__(identifier, sync_port, targets)
        self.__num_targets = len(targets)
        self.state_estimates = initial_states
        self.cov = inv(initial_information)
        self.last_velocity_measurement = None

        self.has_diverged = False

        # cProfile.runctx('self.run()', globals(), locals(), 'prof_%s_2.prof' % (self))
        self.run()

    def covariance(self):
        return self.cov

    def predict(self, target: str, measurement: VelocityMeasurement):
        """
        Make a prediction about the current system state base on the proprioceptive measurement.

        :param target: The robot the measurement is for
        :param measurement: The angular and linear velocity of the system, in m/s
        """

        target_index = self._targets.index(target)
        state_estimate = self.state_estimates[target_index]

        new_estimate = state_estimate.integrate_twist(measurement.vel, self._simulation_meta.time_delta, "x_est_%d" % measurement.time_step)

        self.state_estimates[target_index] = new_estimate

        # Predict the information matrix
        w_x = measurement.vel.angular.skew()
        v_x = measurement.vel.linear.skew()
        Omega = np.zeros((6, 6))
        Omega[0:3, 0:3] = w_x
        Omega[3:6, 0:3] = v_x
        Omega[3:6, 3:6] = w_x

        dt = self._simulation_meta.time_delta

        F = - 0.5 * Omega

        P_ii = self.cov[target_index*6:(target_index+1)*6, target_index*6:(target_index+1)*6].copy()

        P_ii_dot = measurement.covariance + F @ P_ii + P_ii @ F.transpose()

        P_ii_new = P_ii + dt * P_ii_dot

        G = measurement.covariance.copy()

        Q = F @ expm(dt*F) @ P_ii @ expm(dt * F.T) + expm(dt * F) @ P_ii @ expm(dt * F.T) @ F.T + expm(dt * F) @ G @ expm(dt * F.T) - G

        # P_ii_new_2 = scipy.linalg.solve_sylvester(F, F.T, Q)

        self.cov[target_index*6:(target_index+1)*6, target_index*6:(target_index+1)*6] = P_ii_new

        for j in range(len(self.state_estimates)):
            if j == target_index:
                continue
            P_ij = self.cov[target_index*6:(target_index+1)*6, j*6:(j+1)*6].copy()
            P_ij_exp = expm(dt * F) @ P_ij

            self.cov[target_index*6:(target_index+1)*6, j*6:(j+1)*6] = P_ij_exp
            self.cov[j*6:(j+1)*6, target_index*6:(target_index+1)*6] = P_ij_exp.transpose()

        if not is_positive_definite(self.cov):
            print("Central GAME INV: Covariance matrix is not positive definite in Predict step %d. Min eigenvalue is %f" % (measurement.time_step, min(
                np.linalg.eig(self.cov)[0])))

    def update(self, target: str, measurement: LandmarkMeasurement):
        """
        """

        target_index = self._targets.index(target)
        X_i = self.state_estimates[target_index].transform.as_matrix()

        # P_y^(-1)
        meas_information = np.eye(4)
        meas_information[0:3, 0:3] = inv(measurement.covariance)

        y = measurement.meas_pos.homog()
        l = measurement.landmark.location.homog()

        Q_ii = P_s(F(y).T @ G(X_i.T @ meas_information @ (X_i @ y - l))) + F(y).T @ X_i.T @ meas_information @ X_i @ F(y)

        Q = np.zeros(self.cov.shape)
        Q[6*target_index:6*(target_index+1), 6*target_index:6*(target_index+1)] = Q_ii

        # P^+ = P^0 + Q
        cov_est = inv(np.eye(self.cov.shape[0]) + self.cov @ Q) @ self.cov

        if not is_positive_definite(cov_est):
            print("Central GAME INV: Covariance matrix is not positive definite in Update step. Min eigenvalue is %f" % min(
                np.linalg.eigvals(cov_est)))

        innovation_i = se3_vex(P(X_i.T @ meas_information @ (X_i @ y - l) @ y.T @ np.diag([2, 2, 2, 1])))

        full_innovation = np.zeros((self.cov.shape[0],))
        full_innovation[target_index*6:(target_index+1)*6] = innovation_i

        scaled_innovation = - cov_est @ full_innovation

        for i in range(self.__num_targets):
            t = Twist.from_vector(scaled_innovation[6*i:6*(i+1)])
            self.state_estimates[i] = self.state_estimates[i].integrate_twist(t, 1, self.state_estimates[i].name)
        self.cov = cov_est


    def update_R2R(self, target: str, message: R2RMessage, measurement: RobotMeasurement):
        """
        We receive a measurement y_ij - Robot i's measurement of a point on robot j
        We also receive a message from j to i about j's global position. In the global filter, we don't care about this.
        """

        target_i_index = self._targets.index(target)
        target_j_index = self._targets.index(measurement.robot_name)

        X_i = self.state_estimates[target_i_index].transform.as_matrix()
        X_j = self.state_estimates[target_j_index].transform.as_matrix()
        m = message.body_ref_point.homog()

        # print("X_i")
        # print(X_i)
        # print("X_j")
        # print(X_j)

        # y
        meas_pos = measurement.meas_pos.homog()

        # P_y
        meas_covariance = measurement.covariance  # + message.comms_covariance

        # P_y^(-1)
        meas_information = np.eye(4)
        meas_information[0:3, 0:3] = inv(meas_covariance)

        Q_ii = P_s(F(meas_pos).T @ G(X_i.T @ meas_information @ (X_i @ meas_pos - X_j @ m))) + F(meas_pos).T @ X_i.T @ meas_information @ X_i @ F(meas_pos)

        Q_ij = - F(meas_pos).T @ X_i.T @ meas_information @ X_j @ F(m)

        Q_ji = Q_ij.T

        Q_jj = - P_s(F(m).T @ G(X_j.T @ meas_information @ (X_i @ meas_pos - X_j @ m))) + F(m).T @ X_j.T @ meas_information @ X_j @ F(m)

        Q = np.zeros(self.cov.shape)

        Q[target_i_index*6:(target_i_index+1)*6, target_i_index*6:(target_i_index+1)*6] = Q_ii
        Q[target_i_index*6:(target_i_index+1)*6, target_j_index*6:(target_j_index+1)*6] = Q_ij
        Q[target_j_index*6:(target_j_index+1)*6, target_i_index*6:(target_i_index+1)*6] = Q_ji
        Q[target_j_index*6:(target_j_index+1)*6, target_j_index*6:(target_j_index+1)*6] = Q_jj

        topic = "diagnostics/W/%s/%s" % (self._identifier, target)
        data = DiagnosticData(message.time_step, Q)
        self._zmq.send(topic, data)

        # P^+ = P^0 + Q

        # print("RANK: " + str(np.linalg.matrix_rank(self.cov @ Q)))
        # print("PD: " + str(is_positive_definite(Q)))
        # print("MIN EIG: "+ str(min(np.linalg.eigvals(Q))))

        cov_est = inv(np.eye(self.cov.shape[0]) + self.cov @ Q) @ self.cov

        if not is_positive_definite(cov_est):
            print("Central GAME INV: Covariance matrix is not positive definite in R2R Update step at t=%d. Min eigenvalue is %f" % (message.time_step, min(
                np.linalg.eigvals(cov_est))))

        innovation_i = se3_vex(P(X_i.T @ meas_information @ (X_i @ meas_pos - X_j @ m) @ meas_pos.T @ np.diag([2, 2, 2, 1])))
        innovation_j = se3_vex(-P(X_j.T @ meas_information @ (X_i @ meas_pos - X_j @ m) @ m.T @ np.diag([2, 2, 2, 1])))

        innovation = np.zeros((self.cov.shape[0],))
        innovation[target_i_index*6:(target_i_index+1)*6] = innovation_i
        innovation[target_j_index*6:(target_j_index+1)*6] = innovation_j

        scaled_innovation = - cov_est @ innovation

        # print(innovation_i)
        # print(innovation_j)
        # print(scaled_innovation)

        topic = "diagnostics/innovation/%s/%s" % (self._identifier, target)
        data = DiagnosticData(message.time_step, innovation)
        self._zmq.send(topic, data)

        for i in range(self.__num_targets):
            scaled_innovation_i = scaled_innovation[i*6:(i+1)*6]
            t = Twist.from_vector(scaled_innovation_i)
            self.state_estimates[i] = self.state_estimates[i].integrate_twist(t, 1, self.state_estimates[i].name)
        self.cov = cov_est

    def get_outgoing_message(self, target, time_step) -> R2RMessage:
        target_index = self._targets.index(target)
        body_ref_point = Point3DReferenced(marker_point, self.state_estimates[target_index])
        world_ref_point = CoordinateTransform.transform_to_inertial(self.state_estimates[target_index]) * body_ref_point
        return R2RMessage(target, body_ref_point, world_ref_point, self.covariance(), time_step)

    def publish_estimate(self, target, time_step):
        i = self._targets.index(target)
        topic = "filter_estimate/%s/%s" % (self._identifier, target)
        est = Estimate(self.state_estimates[i], self.cov[6*i:6*(i+1), 6*i:6*(i+1)], time_step)
        self._zmq.send(topic, est)

        # We only want to publish this once per time-step
        if i == 0:
            topic = "diagnostics/covariance/%s" % self
            data = DiagnosticData(time_step, self.covariance())
            self._zmq.send(topic, data)
