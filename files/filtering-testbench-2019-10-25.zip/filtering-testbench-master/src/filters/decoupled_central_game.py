import traceback
from typing import List

import cProfile
import numpy as np
import scipy

from data.simulated.robot import marker_point
from src.filters import Filter
from src.filters.abstract_game import Abstract_GAME
from src.geometry.pose import Pose, WorldFrame
from src.geometry.point_referenced import Point3DReferenced
from src.geometry.coordinate_transform import CoordinateTransform
from src.geometry.twist import Twist
from src.structs.messages import VelocityMeasurement, LandmarkMeasurement, RobotMeasurement, R2RMessage, Estimate, \
    DiagnosticData, CrossCovariancePart, ThirdPartyLandmarkUpdate, ThirdPartyRobotUpdate
from src.util.geometry import is_positive_definite, symmetric_projection as P_s, trace_projection as P_t, \
    se3_projection as P, skew, se3_vex
from scipy.linalg import expm
from numpy.linalg import inv


def F(v):
    x = np.zeros((4, 6))
    x[0:3, 0:3] = -skew(v[0:3, 0])
    x[0:3, 3:6] = np.eye(3)
    return x


def G(v):
    x = np.zeros((4, 6))
    x[0:3, 0:3] = skew(v[0:3, 0])
    x[3, 3:6] = v[0:3, 0]
    return x



class Central_GAME_SE3_Decoupled(Abstract_GAME):
    """
    This is the decoupled version of the centralised Game filter. It should produce identical results but with the computations
    distributed across all of the robots, instead of a single centralised computation.

    Each filter tracks the state of a single robot, and a column of the total covariance matrix.
    """

    def __init__(self, identifier: str, sync_port: int, targets: List[str], initial_states: List[Pose],
                 initial_information, all_targets: List[str]):

        assert len(targets) == 1, "Decoupled filter tracks a single target per filter instance"

        super().__init__(identifier, sync_port, targets)

        self._zmq.subscribe('cross_covariance_part/%s' % identifier)
        self._zmq.subscribe('third_party_landmark_updates/%s/%s' % (identifier, targets[0]))

        self._target_index = all_targets.index(targets[0])
        self.__num_targets = len(all_targets)
        self.state_estimate = initial_states[0]
        cov = inv(initial_information)
        self.cov_column = cov[:, self._target_index*6:(self._target_index+1)*6].copy()
        self.last_velocity_measurement = None
        self.all_targets = all_targets

        self.has_diverged = False

        self.K_i = np.eye(6)
        self.block_i = slice(self._target_index*6, (self._target_index+1)*6)

        # cProfile.runctx('self.run()', globals(), locals(), 'prof_%s_2.prof' % (self))
        self.run()

    def covariance(self):
        return self.cov_column[self.block_i]

    def predict(self, target: str, measurement: VelocityMeasurement):
        dt = self._simulation_meta.time_delta

        self.state_estimate = self.state_estimate.integrate_twist(
            measurement.vel, dt, "x_est_%d" % measurement.time_step
        )

        # Predict the information matrix
        w_x = measurement.vel.angular.skew()
        v_x = measurement.vel.linear.skew()
        Omega = np.zeros((6, 6))
        Omega[0:3, 0:3] = w_x
        Omega[3:6, 0:3] = v_x
        Omega[3:6, 3:6] = w_x

        F = - 0.5 * Omega

        Sigma_ii = self.cov_column[self.block_i, :].copy()

        Sigma_ii_dot = measurement.covariance + F @ Sigma_ii + Sigma_ii @ F.transpose()

        self.cov_column[self.block_i, :] = Sigma_ii + dt * Sigma_ii_dot

        self.K_i = expm(dt * F) @ self.K_i

        self.last_velocity_measurement = measurement.time_step

    def synchronise_covariance(self):

        message = CrossCovariancePart(self.last_velocity_measurement, self.K_i)
        ## TODO: We can aviod sending messages if Sigma_ij == 0
        self._zmq.send('cross_covariance_part/%s/%s' % (self._identifier, self._targets[0]), message)

        # print("%s is synchronising covariance" % self)
        for j in range(self.__num_targets):
            topic, data = self._zmq.receive()
            # print("%s received %s" % (self, topic))
            topic_parts = topic.split('/')
            assert isinstance(data, CrossCovariancePart), "Unexpected Message type: " + str(type(data))
            tx_name = topic_parts[2]
            if tx_name == self._targets[0]:
                continue
            self.on_cross_covariance_message(tx_name, data)

        self.K_i = np.eye(6)
        # print("---")

    def on_cross_covariance_message(self, tx_name: str, message: CrossCovariancePart):
        assert message.time_step == self.last_velocity_measurement, "Times are not synchronised"

        K_j = message.K
        j = self.all_targets.index(tx_name)
        block_j = slice(j*6, (j+1)*6)
        Sigma_ji = self.cov_column[block_j, :].copy()
        new_Sigma_ji = K_j @ Sigma_ji @ self.K_i.copy().T
        self.cov_column[block_j, :] = new_Sigma_ji


    def update(self, target: str, measurement: LandmarkMeasurement):

        X_i = self.state_estimate.transform.as_matrix()

        # P_y^(-1)
        meas_information = np.eye(4)
        meas_information[0:3, 0:3] = inv(measurement.covariance)

        y = measurement.meas_pos.homog()
        l = measurement.landmark.location.homog()

        W_ii = P_s(F(y).T @ G(X_i.T @ meas_information @ (X_i @ y - l))) + F(y).T @ X_i.T @ meas_information @ X_i @ F(y)
        W = np.zeros((self.__num_targets*6, self.__num_targets*6))
        W[self.block_i, self.block_i] = W_ii

        cov_full = np.zeros((self.__num_targets*6, self.__num_targets*6))
        cov_full[:, self.block_i] = self.cov_column.copy()
    #
    #     M_ii = np.zeros((6,6))
    #     for j in range(self.__num_targets):
    #         block_j = slice(j*6, (j+1)*6)
    #         M_ii += (self.cov_column[block_j, :] @ W_ii).T @ self.cov_column[block_j, :] @ W_ii
    #
    #     rank = np.linalg.matrix_rank(W_ii)
    #
    #
    #     S, V = np.linalg.eig(M_ii)
    #     # M = cov_full @ W @ (cov_full @ W).T
    #     S_sorted = np.flip(np.sort(S))
    #     V = V[:, np.flip(S.argsort())]
    #     # print(S_sorted)
    #     # print(rank)
    #
    #     S_vec = np.sqrt(S_sorted[0:rank])
    #     S = np.diag(S_vec)
    #     S_inv = np.diag(np.reciprocal(S_vec))
    #     V = V[:, 0:rank]
    #     V = np.append(V, np.zeros((6*(self.__num_targets-1), rank)), axis=0)
    #
    #     T = cov_full @ W @ V @ S_inv
    #
    # # T, S, VT = np.linalg.svd(cov_full @ W)
    #
    #     X = T @ S @ V.T



        # Sigma_delta = np.eye(6 * self.__num_targets) - T @ inv(S_inv + V.T @ T) @ V.T
        Sigma_delta = inv(np.eye(6 * self.__num_targets) + cov_full @ W)

        self.cov_column = Sigma_delta @ self.cov_column

        innovation_i = se3_vex(P(X_i.T @ meas_information @ (X_i @ y - l) @ y.T @ np.diag([2, 2, 2, 1])))

        scaled_innovation = - self.cov_column @ innovation_i

        t = Twist.from_vector(scaled_innovation[self.block_i])
        self.state_estimate = self.state_estimate.integrate_twist(t, 1, self.state_estimate.name)

        for j in range(self.__num_targets):
            if self._target_index == j:
                continue
            block_j = slice(j*6, (j+1)*6)
            name_j = self.all_targets[j]
            message = ThirdPartyLandmarkUpdate(measurement.time_step, Sigma_delta, scaled_innovation[block_j])
            self._zmq.send('third_party_landmark_updates/%s/%s' % (self._identifier, name_j), message)

    def on_third_party_landmark_update(self, target: str, data: ThirdPartyLandmarkUpdate):
        self.cov_column = data.Sigma_delta @ self.cov_column
        t = Twist.from_vector(data.L_i)
        self.state_estimate = self.state_estimate.integrate_twist(t, 1, self.state_estimate.name)

    def update_R2R(self, target: str, message: R2RMessage, measurement: RobotMeasurement):
        """
        We receive a measurement y_ij - Robot i's measurement of a point on robot j
        We also receive a message from j to i about j's global position. In the global filter, we don't care about this.
        """

        target_j_index = self.all_targets.index(measurement.robot_name)

        block_j = slice(target_j_index*6, (target_j_index+1)*6)

        X_i = self.state_estimate.transform.as_matrix()
        X_j = message.state_estimate
        # print("X_i")
        # print(X_i)
        # print("X_j")
        # print(X_j)

        m = message.body_ref_point.homog()

        # y
        z = measurement.meas_pos.homog()

        # P_y
        meas_covariance = measurement.covariance  # + message.comms_covariance

        # P_y^(-1)
        meas_information = np.eye(4)
        meas_information[0:3, 0:3] = inv(meas_covariance)

        W_ii = P_s(F(z).T @ G(X_i.T @ meas_information @ (X_i @ z - X_j @ m))) + F(z).T @ X_i.T @ meas_information @ X_i @ F(z)

        W_ij = - F(z).T @ X_i.T @ meas_information @ X_j @ F(m)

        W_ji = W_ij.T

        W_jj = - P_s(F(m).T @ G(X_j.T @ meas_information @ (X_i @ z - X_j @ m))) + F(m).T @ X_j.T @ meas_information @ X_j @ F(m)

        W = np.zeros((6 * self.__num_targets, 6 * self.__num_targets))

        W[self.block_i, self.block_i] = W_ii
        W[self.block_i, block_j] = W_ij
        W[block_j, self.block_i] = W_ji
        W[block_j, block_j] = W_jj

        topic = "diagnostics/W/%s/%s" % (self._identifier, target)
        data = DiagnosticData(message.time_step, W)
        self._zmq.send(topic, data)

        # P^+ = P^0 + Q

        # print("RANK: " + str(np.linalg.matrix_rank(self.cov @ Q)))
        # print("PD: " + str(is_positive_definite(Q)))
        # print("MIN EIG: "+ str(min(np.linalg.eigvals(Q))))

        cov_full = np.zeros((self.__num_targets*6, self.__num_targets*6))
        # cov_full = np.random.rand(self.__num_targets*6, self.__num_targets*6)
        cov_full[:, self.block_i] = self.cov_column.copy()
        cov_full[:, block_j] = message.covariance_column.copy()

        Sigma_delta = inv(np.eye(6 * self.__num_targets) + cov_full @ W)

        self.cov_column = Sigma_delta @ self.cov_column

        innovation_i = se3_vex(P(X_i.T @ meas_information @ (X_i @ z - X_j @ m) @ z.T @ np.diag([2, 2, 2, 1])))
        innovation_j = se3_vex(P(X_j.T @ meas_information @ (X_j @ m - X_i @ z) @ m.T @ np.diag([2, 2, 2, 1])))

        innovation = np.zeros((self.__num_targets * 6,))
        innovation[self.block_i] = innovation_i
        innovation[block_j] = innovation_j

        scaled_innovation = - self.cov_column @ innovation_i - Sigma_delta @ message.covariance_column @ innovation_j

        t = Twist.from_vector(scaled_innovation[self.block_i])
        self.state_estimate = self.state_estimate.integrate_twist(t, 1, self.state_estimate.name)

        # print(innovation_i)
        # print(innovation_j)
        # print(scaled_innovation)
        topic = "diagnostics/innovation/%s/%s" % (self._identifier, target)
        data = DiagnosticData(message.time_step, innovation)
        self._zmq.send(topic, data)

        for k in range(self.__num_targets):
            if self._target_index == k:
                continue
            block_k = slice(k*6, (k+1)*6)
            target_k = self.all_targets[k]
            message = ThirdPartyLandmarkUpdate(measurement.time_step, Sigma_delta, scaled_innovation[block_k])
            self._zmq.send('third_party_landmark_updates/%s/%s' % (self._identifier, target_k), message)

        # print("Sent all update from %s" % self)


    def get_outgoing_message(self, target, time_step) -> R2RMessage:
        body_ref_point = Point3DReferenced(marker_point, self.state_estimate)
        world_ref_point = CoordinateTransform.transform_to_inertial(self.state_estimate) * body_ref_point
        return R2RMessage(target, body_ref_point, world_ref_point, self.covariance(), time_step, self.state_estimate.transform.as_matrix(), self.cov_column)

    def publish_estimate(self, target, time_step):
        topic = "filter_estimate/%s/%s" % (self._identifier, target)
        est = Estimate(self.state_estimate, self.cov_column[self.block_i, :], time_step)
        self._zmq.send(topic, est)

        # We only want to publish this once per time-step
        topic = "diagnostics/covariance/%s" % self
        data = DiagnosticData(time_step, self.cov_column)
        self._zmq.send(topic, data)
