import traceback
from abc import abstractmethod

import numpy as np
from typing import List

from data.simulated.robot import marker_point
from src.structs.messages import VelocityMeasurement, LandmarkMeasurement, RobotMeasurement, R2RMessage, Estimate, \
    DiagnosticData
from src.util.geometry import trace_projection as P_t, symmetric_projection as P_s, is_positive_definite, symmetric_projection
from src.filters import Filter
from src.geometry.pose import Pose, WorldFrame
from src.geometry.point_referenced import Point3DReferenced
from src.geometry.coordinate_transform import CoordinateTransform
from src.geometry.twist import Twist
from src.geometry.vector3 import Vector3


class Abstract_GAME(Filter):
    """
    Implements the Geometric Approximate Minimum Energy Filter on the SE3 Group
    """

    def on_velocity_measurement(self, target: str, measurement: VelocityMeasurement):
        self.publish_estimate(target, measurement.time_step)

        if not self._has_diverged:
            try:
                self.predict(target, measurement)
            except:
                self._has_diverged = True
                print("%s has diverged in predict at time step %d" % (self, measurement.time_step))
                traceback.print_exc()

    def on_landmark_measurement(self, target: str, measurement: LandmarkMeasurement):
        if not self._has_diverged:
            try:
                self.update(target, measurement)
                # Send a signal indicating that we have finished processing the landmark measurement and propagated out all of
                # the update messages.
                self._zmq_sync.send_signal()
            except:
                self._has_diverged = True
                print("%s has diverged in landmark update at time step %d" % (self, measurement.time_step))
                traceback.print_exc()

    def on_R2R_message(self, target: str, message: R2RMessage, measurement: RobotMeasurement):
        if not self._has_diverged:
            try:
                self.update_R2R(target, message, measurement)

                # Send a signal indicating that we have finished processing the landmark measurement and propagated out all of
                # the update messages.
                self._zmq_sync.send_signal()
            except:
                self._has_diverged = True
                print("%s has diverged in R2R update at time step %d" % (self, measurement.time_step))
                traceback.print_exc()

    @abstractmethod
    def predict(self, target: str, measurement: VelocityMeasurement):
        pass

    @abstractmethod
    def update(self, target: str, measurement: LandmarkMeasurement):
        pass

    @abstractmethod
    def update_R2R(self, target: str, message: R2RMessage, measurement: RobotMeasurement):
        pass

    @abstractmethod
    def publish_estimate(self, target: str, time_step: int):
        pass
