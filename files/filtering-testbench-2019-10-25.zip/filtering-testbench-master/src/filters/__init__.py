"""
Base class for all filters
"""
from abc import ABC, abstractmethod
from multiprocessing import Process

from typing import List

from src.structs.messages import VelocityMeasurement, LandmarkMeasurement, RobotMeasurement, R2RMessage, SimulationMeta, \
    CrossCovariancePart, ThirdPartyLandmarkUpdate
from src.zmq.zmq_channel import ZMQChannel
from src.zmq.zmq_node import ZMQNode


class Filter(ABC):

    def __init__(self, identifier: str, sync_port: int, targets: List[str]):
        """
        :param identifier: A unique name for the filter algorithm and this particular set of parameters
        :param sync_port: A unique tcp port number for the filter to communicate synchronously to the host
        """
        self._identifier = identifier
        self._targets = targets
        self._zmq = ZMQNode()
        self._zmq_sync = ZMQChannel(sync_port)
        self._simulation_meta: SimulationMeta = None
        self._has_diverged = False

        # Subscribe to all the relevant channels
        for t in self._targets:
            self._zmq.subscribe(t + "/velocity")
            self._zmq.subscribe(t + "/landmark")
            self._zmq.subscribe("%s/%s/r2r_message" % (t, self._identifier))

            self._zmq.subscribe("signals/%s/%s/synchronise" % (t, self._identifier))
            self._zmq.subscribe("signals/%s/%s/send_r2r_message" % (t, self._identifier))

    def run(self):
        self._zmq.receive()
        self._zmq.send_signal("signals/ready/%s" % self)
        print("%s Filter is running..." % self)
        last_time = -1
        i = 0
        while True:
            topic, data = self._zmq.receive()
            topic_parts = topic.split('/')
            i += 1

            # print("%s received %s" % (self, topic))

            # Topics with no data:
            if topic == "signals/stop":
                break

            elif topic_parts[0] == "signals" and topic_parts[-1] == "synchronise":
                self._zmq_sync.send_signal()
                self._zmq_sync.receive()
                self.synchronise_covariance()
                self._zmq_sync.send_signal()
                self._zmq_sync.receive()

            elif topic_parts[0] == "signals" and topic_parts[-1] == "send_r2r_message":
                target = topic_parts[1]
                message = self.get_outgoing_message(target, last_time)
                self._zmq_sync.send(message)

            elif isinstance(data, SimulationMeta):
                self._simulation_meta = data

            elif isinstance(data, VelocityMeasurement):
                target = topic_parts[0]
                # if data.time_step != last_time + 1:
                #     print("time mismatch: %d - %d" % (last_time, data.time_step))
                last_time = data.time_step
                self.on_velocity_measurement(target, data)

            elif isinstance(data, LandmarkMeasurement):
                if data.time_step != last_time:
                    print("time mismatch: %d - %d" % (last_time, data.time_step))
                target = topic_parts[0]
                self.on_landmark_measurement(target, data)

            elif isinstance(data, ThirdPartyLandmarkUpdate):
                if data.time_step != last_time:
                    print("time mismatch: %d - %d" % (last_time, data.time_step))
                target = topic_parts[2]
                self.on_third_party_landmark_update(target, data)

            elif topic_parts[-1] == "r2r_message":
                target = topic_parts[0]
                self.on_R2R_message(target, data[0], data[1])
            elif data is not None:
                print("%s received message of unknown type" % self)
                print("Topic: %s, Data:%s" % (topic, data))

        print("%s is stopping" % self)
        self._zmq.print_stats()

    @abstractmethod
    def on_velocity_measurement(self, target: str, measurement: VelocityMeasurement):
        pass

    @abstractmethod
    def on_landmark_measurement(self, target: str, measurement: LandmarkMeasurement):
        pass

    @abstractmethod
    def on_R2R_message(self, target: str, message: R2RMessage, measurement: RobotMeasurement):
        pass

    @abstractmethod
    def get_outgoing_message(self, target: str, time_step: int) -> R2RMessage:
        pass

    def synchronise_covariance(self):
        """ Doesn't necessarily have to be overridden"""
        pass

    def on_cross_covariance_message(self, tx_name: str, message: CrossCovariancePart):
        pass

    def on_third_party_landmark_update(self, target: str, data: ThirdPartyLandmarkUpdate):
        pass

    def __str__(self):
        return "%s_%s" % (self._identifier.replace(' ', '_'), "_".join(self._targets))


class FilterMeta:

    def __init__(self, targets: List[str], identifier: str, process: Process, port: int):
        self.targets = targets
        self.identifier = identifier
        self.process = process
        self.zmq_channel = ZMQChannel(port, bind=True)

    def __getstate__(self):
        """ Exclude the Process handle from being pickled """
        return self.targets, self.identifier

    def __setstate__(self, state):
        self.targets = state[0]
        self.identifier = state[1]
