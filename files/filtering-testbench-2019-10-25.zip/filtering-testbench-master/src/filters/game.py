import numpy as np
from typing import List

from data.simulated.robot import marker_point
from src.filters.abstract_game import Abstract_GAME
from src.structs.messages import VelocityMeasurement, LandmarkMeasurement, RobotMeasurement, R2RMessage, Estimate, \
    DiagnosticData
from src.util.geometry import trace_projection as P_t, symmetric_projection as P_s, is_positive_definite, symmetric_projection
from src.filters import Filter
from src.geometry.pose import Pose, WorldFrame
from src.geometry.point_referenced import Point3DReferenced
from src.geometry.coordinate_transform import CoordinateTransform
from src.geometry.twist import Twist
from src.geometry.vector3 import Vector3


class GAME_SE3(Abstract_GAME):
    """
    Implements the Geometric Approximate Minimum Energy Filter on the SE3 Group
    """

    def __init__(self, identifier: str, sync_port: int, targets: List[str], initial_state: Pose, initial_information: np.ndarray,
                 connection_type='cartan', covariance_estimation_method='CI', alpha=0):
        """
        :param connection_type: Either 'zero' or 'cartan'
        """
        assert len(targets) == 1, "Game filter can only track one target."
        assert connection_type == 'cartan' or connection_type == 'zero', "Invalid Connection type"

        super().__init__(identifier, sync_port, targets)
        self.state_estimate = initial_state
        self.information = initial_information
        self.connection_type = connection_type
        self.covariance_estimation_method = covariance_estimation_method
        self.last_velocity_measurement = None
        self.alpha = alpha

        self.has_diverged = False

        # cProfile.runctx('self.run()', globals(), locals(), 'prof_%s_%s.prof' % (target, identifier))
        self.run()

    def covariance(self):
        return np.linalg.inv(self.information)

    def predict(self, target: str, measurement: VelocityMeasurement):
        """
        Make a prediction about the current system state base on the proprioceptive measurement.

        Based on equations 41 and 42 in Zamani, Trumpf (CDC) 2019
        """

        # if self.last_velocity_measurement is None:
        #     dt = 0
        # else:
        #     dt = (measurement.time_step - self.last_velocity_measurement).total_seconds()
        #
        # self.last_velocity_measurement = measurement.time_step

        self.state_estimate = self.state_estimate.integrate_twist(measurement.vel, self._simulation_meta.time_delta,
                                                                  "x_est_%d" % measurement.time_step)

        # Predict the information matrix
        w_x = measurement.vel.angular.skew()
        v_x = measurement.vel.linear.skew()
        Omega = np.zeros((6, 6))
        if self.connection_type == 'cartan':
            Omega[0:3, 0:3] = w_x
            Omega[3:6, 0:3] = v_x
            Omega[3:6, 3:6] = w_x
            inf_dot = - self.information @ measurement.covariance @ self.information + symmetric_projection(
                self.information @ Omega)

        if self.connection_type == 'zero':
            Omega[0:3, 0:3] = 0.5 * w_x
            Omega[3:6, 0:3] = v_x
            inf_dot = - self.information @ measurement.covariance @ self.information + 2 * symmetric_projection(
                self.information @ Omega)

        inf_new = self.information + self._simulation_meta.time_delta * inf_dot
        if not is_positive_definite(inf_new):
            print("Information matrix is not positive definite in Predict step. Min eigenvalue is %f" % min(
                np.linalg.eig(inf_new)[0]))
            inf_new = self.information

        self.information = inf_new

    def update(self, target: str, measurement: LandmarkMeasurement):
        """
        Implementation is based off Zamani and Trumpf, 2019. Eqn 44 and 45
        The state update equations based on expanding the second equation in (44), and using the identity (18).
        Jack has the derivation of this in his handwritten notes.
        """

        # Estimated transform from the current state to the world frame, base on the current state estimate
        T_world_est = CoordinateTransform.calculate_transform(WorldFrame, self.state_estimate)

        # y\hat
        estimated_measurement = T_world_est * measurement.landmark.location

        # P_y^(-1)
        meas_information = np.linalg.inv(measurement.covariance)

        # p_y^(-1) * (y - y\hat)
        innovation_t = Vector3(meas_information @ (measurement.meas_pos.xyz - estimated_measurement.xyz))
        innovation_R = np.cross(estimated_measurement.xyz, innovation_t.xyz)
        innovation = np.concatenate([innovation_R, innovation_t.xyz])

        # y\hat^T * P_y^(-1) * y\hat
        Q_11_a = estimated_measurement.skew().T @ meas_information @ estimated_measurement.skew()
        # Pt(Ps(innovation * y\hat^T))
        Q_11_b = P_t(P_s(innovation_t.column_vec() @ estimated_measurement.row_vec()))

        Q_11 = Q_11_a + Q_11_b

        if self.connection_type == 'cartan':
            Q_12 = 0.5 * innovation_t.skew() + estimated_measurement.skew() @ meas_information
        elif self.connection_type == 'zero':
            Q_12 = innovation_t.skew() + estimated_measurement.skew() @ meas_information
        else:
            raise Exception("Unknown filter connection type")

        Q = np.block([[Q_11, Q_12], [Q_12.T, meas_information]])

        # P^+ = P^0 + Q
        information_est = self.information + Q

        if not is_positive_definite(information_est):
            print("Information matrix is not positive definite in Update step. Min eigenvalue is %f" % min(
                np.linalg.eigvals(information_est)))
            # Reset the information matrix back to the old value
            information_est = self.information

        ino_scaled = - np.linalg.inv(information_est) @ innovation

        t = Twist.from_vector(ino_scaled)
        self.state_estimate = self.state_estimate.integrate_twist(t, 1, self.state_estimate.name)
        self.information = information_est

    def update_R2R(self, target: str, message: R2RMessage, measurement: RobotMeasurement):

        # Estimated transform from the current state to the world frame, base on the current state estimate
        T_world_est = CoordinateTransform.calculate_transform(WorldFrame, self.state_estimate)

        # y\hat
        estimated_measurement = T_world_est * message.world_ref_point

        measurement_covariance = message.comms_covariance + measurement.covariance

        if self.covariance_estimation_method == 'covariance':
            measurement_covariance += message.state_covariance[3:, 3:]
        elif self.covariance_estimation_method == 'CI':
            measurement_covariance += 1 / self.alpha * message.state_covariance[3:, 3:]
        elif self.covariance_estimation_method == 'context':
            measurement_covariance += 0.01 * np.eye(3)
        # P_y^(-1)
        meas_information = np.linalg.inv(measurement_covariance)

        # p_y^(-1) * (y - y\hat)
        innovation_t = Vector3(meas_information @ (measurement.meas_pos.xyz - estimated_measurement.xyz))
        innovation_R = np.cross(estimated_measurement.xyz, innovation_t.xyz)
        innovation = np.concatenate([innovation_R, innovation_t.xyz])

        # y\hat^T * P_y^(-1) * y\hat
        Q_11_a = estimated_measurement.skew().T @ meas_information @ estimated_measurement.skew()
        # Pt(Ps(innovation * y\hat^T))
        Q_11_b = P_t(P_s(innovation_t.column_vec() @ estimated_measurement.row_vec()))

        Q_11 = Q_11_a + Q_11_b

        if self.connection_type == 'cartan':
            Q_12 = 0.5 * innovation_t.skew() + estimated_measurement.skew() @ meas_information
        elif self.connection_type == 'zero':
            Q_12 = innovation_t.skew() + estimated_measurement.skew() @ meas_information
        else:
            raise Exception("Unknown filter connection type")

        Q = np.block([[Q_11, Q_12], [Q_12.T, meas_information]])

        # P^+ = P^0 + Q
        if self.covariance_estimation_method == 'CI':
            information_est = (1 - self.alpha) * self.information + Q
        else:
            information_est = self.information + Q

        if not is_positive_definite(information_est):
            print("Information matrix is not positive definite in Update step. Min eigenvalue is %f" % min(
                np.linalg.eigvals(information_est)))
            # Reset the information matrix back to the old value
            information_est = self.information

        ino_scaled = - np.linalg.inv(information_est) @ innovation

        t = Twist.from_vector(ino_scaled)
        self.state_estimate = self.state_estimate.integrate_twist(t, 1, self.state_estimate.name)
        self.information = information_est

    def get_outgoing_message(self, target, time_step) -> R2RMessage:
        body_ref_point = Point3DReferenced(marker_point, self.state_estimate)
        world_ref_point = CoordinateTransform.transform_to_inertial(self.state_estimate) * body_ref_point
        return R2RMessage(self._targets[0], body_ref_point, world_ref_point, self.covariance(), time_step)

    def publish_estimate(self,target: str, time_step: int):

        topic = "filter_estimate/%s/%s" % (self._identifier, self._targets[0])
        est = Estimate(self.state_estimate, self.information, time_step)
        self._zmq.send(topic, est)

        topic = "diagnostics/covariance/%s" % self
        data = DiagnosticData(time_step, self.covariance())
        self._zmq.send(topic, data)
