import traceback
from typing import List

import cProfile
import numpy as np

from data.simulated.robot import marker_point
from src.filters import Filter
from src.filters.abstract_game import Abstract_GAME
from src.geometry.pose import Pose, WorldFrame
from src.geometry.point_referenced import Point3DReferenced
from src.geometry.coordinate_transform import CoordinateTransform
from src.geometry.twist import Twist
from src.structs.messages import VelocityMeasurement, LandmarkMeasurement, RobotMeasurement, R2RMessage, Estimate, \
    DiagnosticData
from src.util.geometry import is_positive_definite, symmetric_projection as P_s, trace_projection as P_t, \
    se3_projection as P, skew, se3_vex, is_roughly_positive_definite


def F(v):
    x = np.zeros((4, 6))
    x[0:3, 0:3] = -skew(v[0:3, 0])
    x[0:3, 3:6] = np.eye(3)
    return x


def G(v):
    x = np.zeros((4, 6))
    x[0:3, 0:3] = skew(v[0:3, 0])
    x[3, 3:6] = v[0:3, 0]
    return x



class Central_GAME_SE3(Abstract_GAME):
    """
    Implements the Centralised Geometric Approximate Minimum Energy Filter on the SE3 Group
    Using the cartan connection.
    """

    def __init__(self, identifier: str, sync_port: int, targets: List[str], initial_states: List[Pose],
                 initial_information):

        super().__init__(identifier, sync_port, targets)
        self.__num_targets = len(targets)
        self.state_estimates = initial_states
        self.information = initial_information
        self.last_velocity_measurement = None

        self.has_diverged = False

        # cProfile.runctx('self.run()', globals(), locals(), 'prof_%s_2.prof' % (self))
        self.run()

    def covariance(self):
        return np.linalg.inv(self.information)

    def predict(self, target: str, measurement: VelocityMeasurement):
        """
        Make a prediction about the current system state base on the proprioceptive measurement.

        :param target: The robot the measurement is for
        :param measurement: The angular and linear velocity of the system, in m/s
        """

        # if self.last_velocity_measurement is None:
        #     dt = 0
        # else:
        #     dt = (measurement.time_step - self.last_velocity_measurement).total_seconds()
        #
        # self.last_velocity_measurement = measurement.time_step

        target_index = self._targets.index(target)
        state_estimate = self.state_estimates[target_index]

        new_estimate = state_estimate.integrate_twist(measurement.vel, self._simulation_meta.time_delta, "x_est_%d" % measurement.time_step)

        self.state_estimates[target_index] = new_estimate

        # Predict the information matrix
        w_x = measurement.vel.angular.skew()
        v_x = measurement.vel.linear.skew()
        Omega = np.zeros((6, 6))
        Omega[0:3, 0:3] = w_x
        Omega[3:6, 0:3] = v_x
        Omega[3:6, 3:6] = w_x

        full_Omega = np.zeros(self.information.shape)
        full_Omega[target_index*6:(target_index+1)*6, target_index*6:(target_index+1)*6] = Omega

        full_measurement_covariance = np.zeros(self.information.shape)
        full_measurement_covariance[target_index*6:(target_index+1)*6, target_index*6:(target_index+1)*6] = measurement.covariance

        inf_dot = - self.information @ full_measurement_covariance @ self.information + P_s(self.information @ full_Omega)

        inf_new = self.information + self._simulation_meta.time_delta * inf_dot
        if not is_positive_definite(inf_new):
            print("Central GAME: Information matrix is not positive definite in Predict step. Min eigenvalue is %f" % min(
                np.linalg.eig(inf_new)[0]))
            inf_new = self.information

        self.information = inf_new

    def update(self, target: str, measurement: LandmarkMeasurement):
        """
        """

        target_index = self._targets.index(target)
        X_i = self.state_estimates[target_index].transform.as_matrix()

        # P_y^(-1)
        meas_information = np.eye(4)
        meas_information[0:3, 0:3] = np.linalg.inv(measurement.covariance)

        y = measurement.meas_pos.homog()
        l = measurement.landmark.location.homog()

        Q_ii = P_s(F(y).T @ G(X_i.T @ meas_information @ (X_i @ y - l))) + F(y).T @ X_i.T @ meas_information @ X_i @ F(y)

        Q = np.zeros(self.information.shape)
        Q[6*target_index:6*(target_index+1), 6*target_index:6*(target_index+1)] = Q_ii

        # print("RANK: " + str(np.linalg.matrix_rank(Q)))
        # print("PD: " + str(is_roughly_positive_definite(Q)))
        # print("MIN EIG: "+ str(min(np.linalg.eigvals(Q))))
        # print("MAX EIG: "+ str(max(np.linalg.eigvals(Q))))

        # P^+ = P^0 + Q
        information_est = self.information + Q

        if not is_positive_definite(information_est):
            print("Information matrix is not positive definite in Update step. Min eigenvalue is %f" % min(
                np.linalg.eigvals(information_est)))
            # Reset the information matrix back to the old value
            information_est = self.information

        innovation_i = se3_vex(P(X_i.T @ meas_information @ (X_i @ y - l) @ y.T @ np.diag([2, 2, 2, 1])))

        full_innovation = np.zeros((self.information.shape[0],))
        full_innovation[target_index*6:(target_index+1)*6] = innovation_i

        scaled_innovation = - np.linalg.inv(information_est) @ full_innovation

        for i in range(self.__num_targets):
            t = Twist.from_vector(scaled_innovation[6*i:6*(i+1)])
            self.state_estimates[i] = self.state_estimates[i].integrate_twist(t, 1, self.state_estimates[i].name)
        self.information = information_est

    def update_R2R(self, target: str, message: R2RMessage, measurement: RobotMeasurement):
        """
        We receive a measurement y_ij - Robot i's measurement of a point on robot j
        We also receive a message from j to i about j's global position. In the global filter, we don't care about this.
        """

        target_i_index = self._targets.index(target)
        target_j_index = self._targets.index(measurement.robot_name)

        X_i = self.state_estimates[target_i_index].transform.as_matrix()
        X_j = self.state_estimates[target_j_index].transform.as_matrix()
        m = message.body_ref_point.homog()

        # y
        meas_pos = measurement.meas_pos.homog()

        # P_y
        meas_covariance = measurement.covariance  # + message.comms_covariance

        # P_y^(-1)
        meas_information = np.eye(4)
        meas_information[0:3, 0:3] = np.linalg.inv(meas_covariance)

        Q_ii = P_s(F(meas_pos).T @ G(X_i.T @ meas_information @ (X_i @ meas_pos - X_j @ m))) + F(meas_pos).T @ X_i.T @ meas_information @ X_i @ F(meas_pos)

        Q_ij = - F(meas_pos).T @ X_i.T @ meas_information @ X_j @ F(m)

        Q_ji = Q_ij.T

        Q_jj = - P_s(F(m).T @ G(X_j.T @ meas_information @ (X_i @ meas_pos - X_j @ m))) + F(m).T @ X_j.T @ meas_information @ X_j @ F(m)

        Q = np.zeros(self.information.shape)

        Q[target_i_index*6:(target_i_index+1)*6, target_i_index*6:(target_i_index+1)*6] = Q_ii
        Q[target_i_index*6:(target_i_index+1)*6, target_j_index*6:(target_j_index+1)*6] = Q_ij
        Q[target_j_index*6:(target_j_index+1)*6, target_i_index*6:(target_i_index+1)*6] = Q_ji
        Q[target_j_index*6:(target_j_index+1)*6, target_j_index*6:(target_j_index+1)*6] = Q_jj

        # P^+ = P^0 + Q

        information_est = self.information + Q

        if not is_positive_definite(information_est):
            print("Information matrix is not positive definite in R2R Update step at t=%d. Min eigenvalue is %f" % (message.time_step, min(
                np.linalg.eigvals(information_est))))
            # Reset the information matrix back to the old value
            # information_est = self.information

        innovation_i = se3_vex(P(X_i.T @ meas_information @ (X_i @ meas_pos - X_j @ m) @ meas_pos.T @ np.diag([2, 2, 2, 1])))
        innovation_j = se3_vex(-P(X_j.T @ meas_information @ (X_i @ meas_pos - X_j @ m) @ m.T @ np.diag([2, 2, 2, 1])))

        innovation = np.zeros((self.information.shape[0],))
        innovation[target_i_index*6:(target_i_index+1)*6] = innovation_i
        innovation[target_j_index*6:(target_j_index+1)*6] = innovation_j

        scaled_innovation = - np.linalg.inv(information_est) @ innovation

        for i in range(self.__num_targets):
            scaled_innovation_i = scaled_innovation[i*6:(i+1)*6]
            t = Twist.from_vector(scaled_innovation_i)
            self.state_estimates[i] = self.state_estimates[i].integrate_twist(t, 1, self.state_estimates[i].name)
        self.information = information_est

    def get_outgoing_message(self, target, time_step) -> R2RMessage:
        target_index = self._targets.index(target)
        body_ref_point = Point3DReferenced(marker_point, self.state_estimates[target_index])
        world_ref_point = CoordinateTransform.transform_to_inertial(self.state_estimates[target_index]) * body_ref_point
        return R2RMessage(target, body_ref_point, world_ref_point, self.covariance(), time_step)

    def publish_estimate(self, target, time_step):
        i = self._targets.index(target)
        topic = "filter_estimate/%s/%s" % (self._identifier, target)
        est = Estimate(self.state_estimates[i], self.information[6*i:6*(i+1), 6*i:6*(i+1)], time_step)
        self._zmq.send(topic, est)

        # We only want to publish this once per time-step
        if i == 0:
            topic = "diagnostics/covariance/%s" % self
            data = DiagnosticData(time_step, self.covariance())
            self._zmq.send(topic, data)
