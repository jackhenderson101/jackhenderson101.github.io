from typing import List, Tuple

from src.geometry.pose import Pose
from src.geometry.twist import Twist
import numpy as np

def circular_trajectory(initial_pose: Pose, velocity: Twist, num_steps, dt, name) -> List[Tuple[Pose, Twist]]:
    """
    Robot moves on a fixed circular trajectory in the x-y plane. We assume that linear velocity only has an x component
    and angular velocity only has a z component
    """
    current_pose = initial_pose

    trajectory = [(initial_pose, velocity)]
    for i in range(1, num_steps):

        current_pose = current_pose.integrate_twist(velocity, dt,  "%s_%d" % (name, i))
        trajectory.append((current_pose, velocity))

    return trajectory


def stationary_trajectory(initial_pose, num_steps: int) -> List[Tuple[Pose, Twist]]:
    """
    A trajectory that remains in a fixed location.
    """

    trajectory = [(initial_pose, Twist.zero())] * num_steps
    return trajectory


def random_trajectory(initial_pose: Pose, max_velocity: Twist, num_steps: int, dt: float, name):


    trajectory = [(initial_pose, Twist.zero())]

    current_pose = initial_pose
    current_vel = Twist.zero()

    for i in range(1, num_steps):

        current_vel = Twist.from_vector(0.95*(current_vel.as_vector() + np.random.normal(scale=0.1, size=6)))

        current_pose = current_pose.integrate_twist(current_vel, dt,  "%s_%d" % (name, i))
        trajectory.append((current_pose, current_vel))

    return trajectory
