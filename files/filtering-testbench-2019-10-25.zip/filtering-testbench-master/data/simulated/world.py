from typing import List, Dict
import numpy as np
from src.structs.landmark import Landmark
from data.simulated.robot import Robot
from src.structs.messages import R2RMessage


class World:
    """
    Contains all of the elements required to simulate the world. This includes robot trajectories, robot's internal
    measurements, landmark measurements, all sources of noise etc.
    """

    def __init__(self, seed, total_time, time_delta):
        self.__seed = seed
        self.__rand = np.random.RandomState(seed=seed)
        self.__can_see_landmark = None  # lambda robot, landmark, time_step: False
        self.__can_see_robot = None  # lambda robot_tx, robot_rx, time_step: False

        self.total_time = total_time
        self.time_delta = time_delta
        self.num_steps = int(np.ceil(total_time / time_delta))

        self.landmarks: List[Landmark] = []

        self.robots: Dict[str, Robot] = {}

    def add_landmark(self, landmark: Landmark):
        """ Add a landmark to the system at the specified (X,Y,Z) coordinates """
        self.landmarks.append(landmark)

    def set_can_see_landmark(self, func):
        """
        func(robot, landmark, time) returns True if a robot can see the specified landmark at the current time.
        """
        self.__can_see_landmark = func

    def can_see_landmark(self, robot, landmark, time_step):
        if self.__can_see_landmark:
            return self.__can_see_landmark(robot, landmark, time_step)

    def num_landmarks(self):
        return len(self.landmarks)

    def add_robot(self, robot: Robot):
        """ Add a robot to the state of the system """
        self.robots[robot.name] = robot

    def num_robots(self):
        return len(self.robots)

    def set_can_see_robot(self, func):
        self.__can_see_robot = func

    def can_see_robot(self, robot_tx: Robot, robot_rx: Robot, time_step: int):
        if self.__can_see_robot:
            return self.__can_see_robot(robot_tx, robot_rx, time_step)

    def set_communication_noise(self, noise):
        self.communication_noise = noise

    def rand_int(self):
        return self.__rand.randint(2**31)

    def add_communication_noise(self, message: R2RMessage) -> R2RMessage:
        message.world_ref_point += self.communication_noise @ (np.array([1, 1, 0]) * self.__rand.normal(0, 1, (3,)))
        message.comms_covariance = self.communication_noise @ self.communication_noise.T
        return message

