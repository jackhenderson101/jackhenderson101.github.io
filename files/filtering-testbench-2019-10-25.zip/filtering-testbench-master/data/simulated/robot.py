from __future__ import annotations

from warnings import warn

import numpy as np
from typing import Tuple, List

from src.structs.landmark import Landmark
from src.geometry.pose import Pose, WorldFrame
from src.geometry.point_referenced import Point3DReferenced
from src.geometry.coordinate_transform import CoordinateTransform
from src.geometry.twist import Twist
from src.structs.messages import VelocityMeasurement, LandmarkMeasurement, RobotMeasurement

# This is the point fixed to the robot which can be measured by other robots.
from src.geometry.vector3 import Vector3

marker_point = [1, 0, 0]


class Robot:
    """
    Represents a simulated robot and contains data about its trajectory over time, its proprioceptive
    measurements.
    """

    def __init__(self, name: str, initial_position: Pose, trajectory: List[Tuple[Pose, Twist]], seed: int, dt: float):
        self.__rand = np.random.RandomState(seed=seed)
        self.__dt = dt
        self.name = name
        self.initial_pose = initial_position
        self.trajectory = trajectory

        self.error_angular_vel = np.zeros((3, 3))
        self.error_linear_vel = np.zeros((3, 3))
        self.error_landmark = np.zeros((3, 3))
        self.error_inter_robot = np.zeros((3, 3))
        self.covariance_velocity = np.zeros((6, 6))

        self.covariance_landmark = self.error_landmark @ self.error_landmark.T
        self.covariance_inter_robot = self.error_inter_robot @ self.error_inter_robot.T

    def set_measurement_errors(self, angular_vel, linear_vel, landmark, inter_robot):
        self.error_angular_vel = angular_vel
        self.error_linear_vel = linear_vel
        self.error_landmark = landmark
        self.error_inter_robot = inter_robot

        self.covariance_velocity = np.block([
            [angular_vel @ angular_vel.T, np.zeros((3, 3))],
            [np.zeros((3, 3)), linear_vel @ linear_vel.T]
        ])
        self.covariance_landmark = self.error_landmark @ self.error_landmark.T
        self.covariance_inter_robot = inter_robot @ inter_robot.T

    def get_velocity_measurement(self, time_step) -> VelocityMeasurement:
        (_, velocity) = self.trajectory[time_step]

        noise_angular = Vector3(self.error_angular_vel @ (np.array([0, 0, 1]) * self.__rand.normal(0, 1, (3,))))
        measured_angular = velocity.angular + noise_angular

        noise_linear = Vector3(self.error_linear_vel @ (np.array([1, 0, 0]) * self.__rand.normal(0, 1, (3,))))
        measured_linear = velocity.linear + noise_linear

        twist = Twist(measured_angular, measured_linear)
        return VelocityMeasurement(twist, self.covariance_velocity, time_step)

    def get_landmark_measurement(self, landmark: Landmark, time) -> LandmarkMeasurement:
        """
        Return a relative measurement between the robot and the specified landmark at the given time step.
        Noise is added to the measurement.
        """

        (pose, _) = self.trajectory[time]

        # Transformation from world frame to current pose, xt
        T_world_xt = CoordinateTransform.calculate_transform(WorldFrame, pose)

        # True relative position of the landmark
        landmark_xt = T_world_xt * landmark.location

        measurement_noise = self.error_landmark @ (np.array([1, 1, 0]) * self.__rand.normal(0, 1, (3,)))

        # Add some measurement noise
        landmark_measurement = landmark_xt + measurement_noise

        return LandmarkMeasurement(landmark_measurement, self.covariance_landmark, landmark, time)

    def get_robot_measurement(self, other_robot: Robot, time) -> RobotMeasurement:
        """
        Return a vector to the other robot in this robot's coordinate system
        """

        (self_pose, _) = self.trajectory[time]
        (other_pose, _) = other_robot.trajectory[time]

        measurement_point = Point3DReferenced(marker_point, other_pose)

        # Transformation from self pose to other robot's pose
        T_other_to_self = CoordinateTransform.calculate_transform(other_pose, self_pose)

        relative_position = T_other_to_self * measurement_point
        measurement_noise = self.error_inter_robot @ (np.array([1, 1, 0]) * self.__rand.normal(0, 1, (3,)))

        # warn("Measurement noise disabled")
        measurement = relative_position + measurement_noise

        return RobotMeasurement(measurement, self.covariance_inter_robot, other_robot.name, time)
