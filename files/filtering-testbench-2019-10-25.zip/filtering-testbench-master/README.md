# Multi Robot Filtering Test Bench
_Jack Henderson_

## Overview
The multi robot filtering testbench is a python-based package that has been designed to test a variety of  collaborative localisation algorithms, specifically on SE3.

The simulation consists of multiple robots moving along pre-defined trajectories. Each robot can measure its own linear and angular velocities and also make relative measurements of fixed, known landmarks. Robots can also make relative measurements to other robots in the world, as well as communicate their estimated position to other robots.

The process of running a simulation is as follows:
* A `World` is defined, which contains information about the positions of landmarks, trajectories of robots, total simulation time, noise properties etc.
* A list of filters is defined, specifying any filter parameters, which robot the filter is tracking and what the initial estimate is.
* The simulation then initialises each filter in a separate process
* The simulation starts and velocity, landmark, and inter-robot measurements are communicated to each of the filter processes. Each filter processes these measurements independently.
* If two robots perform an inter-robot communication, the two corresponding filters are synchronised before the message is sent. This ensures that both robots have processed all measurements up to the current time step.
* Each filter publishes their current estimate at every time step.
* A separate process records all the filter estimates and writes a datafile at the end of the simulation containing all the relevant information about the simulation.
* The datafile can then be post-processed to generate plots of trajectory, errors against ground truth data, and summary statistics.



## Implemented Filters
Currently the following filters have been implemented:

* **Geometric Approximate Minimum Energy (GAME) Filter:**  
    The filter is based on two papers which detail the problem description and the filter equations for the distributed game filter.  
    * Zamani and Hunjet, _Collaborative Pose Filtering Using Relative Measurements and Communications_, 2019 12th Asian Control Conference (ASCC)
    * Zamani and Trumpf, _Discrete update pose ﬁlter on the special Euclidean group SE(3)_, CDC 2019

* **Centralised GAME Filter**:  
  This filter has been derived as a centralised version of the GAME filter with a slightly modified cost functional. A single filter estimates the state of all robots. The purpose of this filter was to study how the cross-covariance terms between robot states evolved in the hopes of improving the decentralised filter where this information is not available.
  
  A decoupled version of this filter is also implemented, as will be presented in IFAC2020 (pending acceptance).

## Getting Started
The testbench has been developed and tested on Windows 10, with Python 3.7.3. No guarantees for other versions or OS's.

1. Clone this repository to a folder on your computer
1. Download and install [Anaconda Python](https://www.anaconda.com/distribution/) if it isn't already installed . You might want [MiniConda](https://docs.conda.io/en/latest/miniconda.html) instead for a smaller download 
1. Open an Anaconda Prompt or Terminal window and `cd` to the repository
1. `conda env create --file environment.yml`
1. `conda activate filtering_testbench_env`
1. `python src/tests/simulations/two_robot_simply.py`

## Some important details about the testbench
### Communication Between Processes
As each filter runs in a separate process, there needs to be method of inter-process communication (IPC). This is implemented through [ZeroMQ](https://zeromq.org/), a widely used, language agnostic, TCP-based message queue library. A ZeroMQ process is initialised which acts as a message broker which other processes can [publish and subscribe](https://en.wikipedia.org/wiki/Publish%E2%80%93subscribe_pattern) to. This configuration allows many processes to run independently and in parallel. The core simulation process (the core) publishes measurement data to topics at a very high rate. Filter processes queue up the messages and can then independently process them at a slower rate. At the end of the simulation, the core waits for all filter processes to finish before terminating itself.

### Initialisation of Channels
One of the quirks/features of ZeroMQ is that when a connection is created, it is not immediately opened. For us, this means that we must confirm that all subscriber processes must be fully initialised and have an open connection to the broker before we start sending any data. If we don't some processes may miss the first few messages.

To achieve this, the simulation core will publish a `signals/init` message at regular intervals. When a subscriber receives this message, it will publish a `signals/ready` message. Once the core has received the right number of ready messages, it knows that all processes are ready.

### Synchronous Channels

Separate to the publish/subscribe channels, each filter also has a unique synchronous channel for communication. This is used by the core to wait for a filter to 'catch up' and process all of the messages in the queue. This is crucial in the case where a robot needs to send its state estimate to another robot - as we must ensure that the state estimate at the current time step is sent. To synchronise with a particular filter, the core will publish a `signals/{robot_name}/{filter_name}/send_r2r_message` and then waits for the filter process on the synchronous channel. The filter process may be busy processing other messages, and when it eventually receives the synchronise signal, it will communicate back to the core over the synchronous channel and send its current state estimate. The core then knows that the filter is up-to-date and can then send this state estimate to other robots.

### Measurements
Measurement data is sent through the following topics:
* `{robot_name}/velocity` Contains the interoceptive angular and linear velocity measurements
* `{robot_name}/landmark` Position of a landmark relative to the body-fixed-frame of the robot
* `{robot_name}/{filter_name}/r2r_message` Contains both a communicated state from another robot and a measurement of the relative position of that robot in the BFF

### Additional Messages
* `meta` Contains metadata relating to the simulation (see `SimulationMeta` class)
* `ground_truth/{robot_name}` The true pose of a robot.
* `filter_estimate/{filter_name}/{robot_name}` The estimated pose of the robot

### End of Simulation
At the end of the simulation, when all of the measurements have been published, the core must wait for each filter to process any remaining messages in the queue. It publishes a `signals/{robot_name}/{filter_name}/synchronise` message to each filter and waits for each one on the synchronous channel. One each filter has processed all messages, it sends a signal back over the synchronous channel. Once all filters are synchronised, a `signals/stop` message is published which indicates to all processes that the simulation has ended. Subscribers perform any final cleanup and then terminate.
